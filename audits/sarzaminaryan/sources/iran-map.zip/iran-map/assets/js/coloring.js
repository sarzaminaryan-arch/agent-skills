/**
 * Step 7: Map coloring modes - default / population / area / climate
 * - Toggle and legend (gradient + numeric ticks; colorblind-safe categorical for climate)
 * - Switching must not jank at county level (cross-fade with opacity)
 * - Don't change behavior, only visual
 */
(function() {
    'use strict';

    function initColoring() {
        const container = document.getElementById('iran-map-container');
        const provincesGroup = document.getElementById('provinces-group');
        const countiesGroup = document.getElementById('counties-group');
        const regionsDataEl = document.getElementById('iran-regions-data');
        if (!container || !provincesGroup) return;

        let regionsData = [];
        if (regionsDataEl) {
            try { regionsData = JSON.parse(regionsDataEl.textContent); } catch(e) {}
        }
        const regionBySlug = {};
        regionsData.forEach(r => {
            if (r.slug_en) regionBySlug[r.slug_en] = r;
        });

        // Create controls UI
        const colorControls = document.createElement('div');
        colorControls.className = 'iran-map-color-controls';
        colorControls.setAttribute('aria-label', 'حالت رنگ‌آمیزی نقشه');

        const toggle = document.createElement('div');
        toggle.className = 'iran-map-color-toggle';
        toggle.setAttribute('role', 'group');
        toggle.setAttribute('aria-label', 'حالت رنگ‌آمیزی');

        const modes = [
            { id: 'default', label: 'پیش‌فرض' },
            { id: 'population', label: 'جمعیت' },
            { id: 'area', label: 'مساحت' },
            { id: 'climate', label: 'اقلیم' }
        ];

        const legend = document.createElement('div');
        legend.className = 'iran-map-legend';
        legend.setAttribute('aria-live', 'polite');

        let currentMode = localStorage.getItem('iran-map-color-mode') || 'default';
        container.setAttribute('data-color-mode', currentMode);

        function getMinMax(key) {
            let min = Infinity, max = -Infinity;
            regionsData.forEach(r => {
                if (r.type !== 'province') return;
                const val = r[key];
                if (val == null) return;
                if (val < min) min = val;
                if (val > max) max = val;
            });
            return { min, max };
        }

        const popMinMax = getMinMax('population');
        const areaMinMax = getMinMax('area_km2');

        // Climate categories - collect unique
        const climates = [...new Set(regionsData.filter(r => r.type === 'province' && r.climate).map(r => r.climate))];
        // Colorblind-safe palette mapping
        const climateColors = {
            'گرم و شرجی': 'var(--climate-desert)',
            'نیمه‌خشک': 'var(--climate-semi-arid)',
            'مدیترانه‌ای': 'var(--climate-mediterranean)',
            'سرد کوهستانی': 'var(--climate-cold-mountain)',
            'مرطوب': 'var(--climate-humid)',
            'خیلی مرطوب': 'var(--climate-very-humid)',
            'معتدل': 'var(--climate-temperate)',
            'گرم و خشک': 'var(--climate-desert)',
            'سرد': 'var(--climate-cold-mountain)',
            'نیمه‌مرطوب': 'var(--climate-temperate)',
            'خشک': 'var(--climate-desert)',
            'گرم': 'var(--climate-hot)'
        };
        // Fallback palette for unknown climates - use Okabe-Ito
        const fallbackPalette = ['#E69F00', '#56B4E9', '#009E73', '#0072B2', '#D55E00', '#CC79A7', '#F0E442', '#000000'];
        function getClimateColor(climate, index) {
            return climateColors[climate] || fallbackPalette[index % fallbackPalette.length];
        }

        function interpolateColor(value, min, max) {
            // Map value to gradient #D9F1EE → #2BB3A3 → #0B5F5A
            // Use CSS variables: --color-map-50 (light), --color-map-400 (mid), --color-map-700 (dark)
            // For JS we need actual hex, but we can use linear interpolation between 3 stops
            // Normalize 0-1
            const t = (value - min) / (max - min || 1);
            // We'll interpolate between light (0) -> mid (0.5) -> dark (1)
            // Light: #D9F1EE (217,241,238), Mid: #2BB3A3 (43,179,163), Dark: #0B5F5A (11,95,90)
            let r, g, b;
            if (t < 0.5) {
                const localT = t * 2;
                r = 217 + (43 - 217) * localT;
                g = 241 + (179 - 241) * localT;
                b = 238 + (163 - 238) * localT;
            } else {
                const localT = (t - 0.5) * 2;
                r = 43 + (11 - 43) * localT;
                g = 179 + (95 - 179) * localT;
                b = 163 + (90 - 163) * localT;
            }
            return `rgb(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)})`;
        }

        function applyColoring(mode) {
            if (!mode) mode = 'default';
            currentMode = mode;
            container.setAttribute('data-color-mode', mode);
            try { localStorage.setItem('iran-map-color-mode', mode); } catch(e) {}

            // Cross-fade with opacity to avoid jank at county level
            container.classList.add('is-color-switching');

            const provinces = provincesGroup.querySelectorAll('.province');
            const counties = countiesGroup ? countiesGroup.querySelectorAll('.county') : [];

            if (mode === 'default') {
                provinces.forEach(path => {
                    path.style.fill = '';
                    path.classList.remove('climate-desert','climate-semi-arid','climate-mediterranean','climate-cold-mountain','climate-humid','climate-very-humid','climate-temperate','climate-hot');
                });
                counties.forEach(path => {
                    path.style.fill = '';
                });
            } else if (mode === 'population') {
                provinces.forEach(path => {
                    const slug = path.dataset.slug;
                    const rd = regionBySlug[slug];
                    if (rd && rd.population) {
                        path.style.fill = interpolateColor(rd.population, popMinMax.min, popMinMax.max);
                    } else {
                        path.style.fill = 'var(--color-map-50)';
                    }
                    path.classList.remove('climate-desert','climate-semi-arid','climate-mediterranean','climate-cold-mountain','climate-humid','climate-very-humid','climate-temperate','climate-hot');
                });
                counties.forEach(path => {
                    const slug = path.dataset.slug;
                    const rd = regionBySlug[slug];
                    if (rd && rd.population) {
                        // For counties, use same scale but maybe lighter
                        path.style.fill = interpolateColor(rd.population, popMinMax.min * 0.1, popMinMax.max);
                    } else {
                        path.style.fill = '';
                    }
                });
            } else if (mode === 'area') {
                provinces.forEach(path => {
                    const slug = path.dataset.slug;
                    const rd = regionBySlug[slug];
                    if (rd && rd.area_km2) {
                        path.style.fill = interpolateColor(rd.area_km2, areaMinMax.min, areaMinMax.max);
                    } else {
                        path.style.fill = 'var(--color-map-50)';
                    }
                    path.classList.remove('climate-desert','climate-semi-arid','climate-mediterranean','climate-cold-mountain','climate-humid','climate-very-humid','climate-temperate','climate-hot');
                });
                counties.forEach(path => {
                    const slug = path.dataset.slug;
                    const rd = regionBySlug[slug];
                    if (rd && rd.area_km2) {
                        path.style.fill = interpolateColor(rd.area_km2, areaMinMax.min * 0.1, areaMinMax.max);
                    } else {
                        path.style.fill = '';
                    }
                });
            } else if (mode === 'climate') {
                provinces.forEach(path => {
                    const slug = path.dataset.slug;
                    const rd = regionBySlug[slug];
                    const climate = rd ? rd.climate : null;
                    // Remove previous climate classes
                    path.classList.remove('climate-desert','climate-semi-arid','climate-mediterranean','climate-cold-mountain','climate-humid','climate-very-humid','climate-temperate','climate-hot');
                    path.style.fill = '';
                    if (climate) {
                        // Map climate string to class
                        const lower = climate.toLowerCase();
                        if (lower.includes('خشک') && lower.includes('گرم')) path.classList.add('climate-desert');
                        else if (lower.includes('نیمه‌خشک')) path.classList.add('climate-semi-arid');
                        else if (lower.includes('مدیترانه')) path.classList.add('climate-mediterranean');
                        else if (lower.includes('سرد') && lower.includes('کوه')) path.classList.add('climate-cold-mountain');
                        else if (lower.includes('خیلی مرطوب')) path.classList.add('climate-very-humid');
                        else if (lower.includes('مرطوب')) path.classList.add('climate-humid');
                        else if (lower.includes('معتدل') || lower.includes('نیمه‌مرطوب')) path.classList.add('climate-temperate');
                        else if (lower.includes('گرم')) path.classList.add('climate-hot');
                        else {
                            // Fallback color via inline style using palette
                            const idx = climates.indexOf(climate);
                            path.style.fill = getClimateColor(climate, idx >=0 ? idx : 0);
                        }
                    }
                });
                counties.forEach(path => {
                    path.style.fill = '';
                });
            }

            // Update legend
            updateLegend(mode);

            // Remove switching class after transition
            setTimeout(() => {
                container.classList.remove('is-color-switching');
            }, 400);

            // Update toggle active state
            toggle.querySelectorAll('button').forEach(btn => {
                if (btn.dataset.mode === mode) btn.classList.add('is-active');
                else btn.classList.remove('is-active');
            });
        }

        function updateLegend(mode) {
            if (!legend) return;
            legend.innerHTML = '';
            const title = document.createElement('div');
            title.className = 'iran-map-legend-title';
            const modeLabel = modes.find(m => m.id === mode)?.label || mode;
            title.textContent = `راهنما: ${modeLabel}`;
            legend.appendChild(title);

            if (mode === 'default') {
                legend.innerHTML += '<div style="font-size:11px;">رنگ پیش‌فرض نقشه</div>';
            } else if (mode === 'population') {
                const gradient = document.createElement('div');
                gradient.className = 'iran-map-legend-gradient';
                legend.appendChild(gradient);
                const ticks = document.createElement('div');
                ticks.className = 'iran-map-legend-ticks';
                ticks.innerHTML = `<span>${popMinMax.min.toLocaleString('fa-IR')}</span><span>${Math.round((popMinMax.min+popMinMax.max)/2).toLocaleString('fa-IR')}</span><span>${popMinMax.max.toLocaleString('fa-IR')}</span>`;
                legend.appendChild(ticks);
                const label = document.createElement('div');
                label.style.fontSize = '10px';
                label.style.marginTop = '4px';
                label.textContent = 'جمعیت (نفر)';
                legend.appendChild(label);
            } else if (mode === 'area') {
                const gradient = document.createElement('div');
                gradient.className = 'iran-map-legend-gradient';
                legend.appendChild(gradient);
                const ticks = document.createElement('div');
                ticks.className = 'iran-map-legend-ticks';
                ticks.innerHTML = `<span>${areaMinMax.min.toLocaleString('fa-IR')}</span><span>${Math.round((areaMinMax.min+areaMinMax.max)/2).toLocaleString('fa-IR')}</span><span>${areaMinMax.max.toLocaleString('fa-IR')}</span>`;
                legend.appendChild(ticks);
                const label = document.createElement('div');
                label.style.fontSize = '10px';
                label.style.marginTop = '4px';
                label.textContent = 'مساحت (km²)';
                legend.appendChild(label);
            } else if (mode === 'climate') {
                const cat = document.createElement('div');
                cat.className = 'iran-map-legend-categorical';
                climates.slice(0, 8).forEach((cl, idx) => {
                    const item = document.createElement('div');
                    item.className = 'iran-map-legend-item';
                    const color = document.createElement('span');
                    color.className = 'iran-map-legend-color';
                    color.style.background = getClimateColor(cl, idx);
                    const label = document.createElement('span');
                    label.textContent = cl;
                    item.appendChild(color);
                    item.appendChild(label);
                    cat.appendChild(item);
                });
                legend.appendChild(cat);
            }
        }

        // Build toggle buttons
        modes.forEach(m => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.dataset.mode = m.id;
            btn.textContent = m.label;
            btn.setAttribute('aria-label', `حالت ${m.label}`);
            if (m.id === currentMode) btn.classList.add('is-active');
            btn.addEventListener('click', () => applyColoring(m.id));
            toggle.appendChild(btn);
        });

        colorControls.appendChild(toggle);
        colorControls.appendChild(legend);
        container.appendChild(colorControls);

        // Initial apply
        applyColoring(currentMode);

        // Re-apply when counties loaded (for county level coloring)
        const observer = new MutationObserver(() => {
            if (currentMode !== 'default') {
                applyColoring(currentMode);
            }
        });
        observer.observe(countiesGroup, { childList: true });

        // Expose for debugging
        window.IranMapColoring = {
            applyColoring,
            getCurrentMode: () => currentMode,
            getMinMax: (key) => key === 'population' ? popMinMax : areaMinMax,
            getClimates: () => climates
        };
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initColoring);
    } else {
        initColoring();
    }
})();
