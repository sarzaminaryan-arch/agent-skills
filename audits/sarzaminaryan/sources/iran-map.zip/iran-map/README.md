# Iran Map Theme - پوسته نقشه ایران

پوسته سبک، RTL، فارسی، بدون jQuery، بدون Page Builder، برای نقشه تعاملی ایران.

## ویژگی‌ها
- زبان: fa_IR، lang="fa" و dir="rtl"
- فونت خودمیزبان Vazirmatn FD (woff2, preload, font-display: swap)
- Logical CSS properties (margin-inline, padding-inline, etc)
- بدون jQuery
- ترجمه‌پذیر (textdomain: iran-map)
- پشتیبانی از CPT region (استان > شهرستان) با آدرس‌های تمیز /isfahan/kashan/
- قالب‌های ساده fallback: index, front-page, single-region, archive-region, page, 404

## نصب
1. کپی پوشه iran-map به wp-content/themes/
2. فعال‌سازی از نمایش > پوسته‌ها
3. تنظیم پیوند یکتا روی «نام نوشته»
4. تنظیم زبان سایت روی فارسی
