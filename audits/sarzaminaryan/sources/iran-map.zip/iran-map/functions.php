<?php
if (!defined('ABSPATH')) exit;

/**
 * Iran Map Theme - Lightweight, RTL, No jQuery, No Page Builder
 * Text Domain: iran-map
 */

define('IRAN_MAP_VERSION', '0.8.0');
define('IRAN_MAP_PATH', get_template_directory());
define('IRAN_MAP_URL', get_template_directory_uri());

// Load textdomain
add_action('after_setup_theme', function() {
    load_theme_textdomain('iran-map', IRAN_MAP_PATH . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);
    add_theme_support('responsive-embeds');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links');

    register_nav_menus([
        'primary' => __('منوی اصلی', 'iran-map'),
        'footer'  => __('منوی فوتر', 'iran-map'),
    ]);

    $GLOBALS['content_width'] = 1200;

    // Additional image sizes for hero - AVIF/WebP via WordPress will generate srcset if supported
    add_image_size('region-hero', 1200, 600, true);
    add_image_size('region-hero-2x', 2400, 1200, true);
    add_image_size('region-thumb', 400, 300, true);
});

// Enqueue styles - no jQuery - Step 7 design tokens + Step 8 performance
add_action('wp_enqueue_scripts', function() {
    // Design tokens first - critical
    wp_enqueue_style('iran-map-tokens', IRAN_MAP_URL . '/assets/css/design-tokens.css', [], IRAN_MAP_VERSION);
    wp_enqueue_style('iran-map-style', get_stylesheet_uri(), ['iran-map-tokens'], IRAN_MAP_VERSION);
    wp_enqueue_style('iran-map-templates', IRAN_MAP_URL . '/assets/css/templates.css', ['iran-map-style'], IRAN_MAP_VERSION);
    
    // Map CSS only where needed (front page) - performance
    if (is_front_page()) {
        $map_css = file_exists(IRAN_MAP_PATH . '/assets/css/map.min.css') ? 'map.min.css' : 'map.css';
        wp_enqueue_style('iran-map-map', IRAN_MAP_URL . '/assets/css/' . $map_css, ['iran-map-style'], IRAN_MAP_VERSION);
    }
    
    // Critical CSS inline for above-the-fold (hero, breadcrumb, quick-facts)
    $critical_css = '';
    $critical_path = IRAN_MAP_PATH . '/assets/css/critical.min.css';
    if (file_exists($critical_path)) {
        $critical_css = file_get_contents($critical_path);
    } else {
        $critical_path2 = IRAN_MAP_PATH . '/assets/css/critical.css';
        if (file_exists($critical_path2)) $critical_css = file_get_contents($critical_path2);
    }
    if ($critical_css) {
        wp_add_inline_style('iran-map-style', $critical_css);
    }

    // Map JS only where needed (front page) - performance
    if (is_front_page()) {
        $map_js = file_exists(IRAN_MAP_PATH . '/assets/js/map.min.js') ? 'map.min.js' : 'map.js';
        $coloring_js = file_exists(IRAN_MAP_PATH . '/assets/js/coloring.min.js') ? 'coloring.min.js' : 'coloring.js';
        wp_enqueue_script('iran-map-map', IRAN_MAP_URL . '/assets/js/' . $map_js, [], IRAN_MAP_VERSION, true);
        wp_enqueue_script('iran-map-coloring', IRAN_MAP_URL . '/assets/js/' . $coloring_js, ['iran-map-map'], IRAN_MAP_VERSION, true);
    }
    // View Transitions API helper (fade fallback) - lightweight
    $trans_js = file_exists(IRAN_MAP_PATH . '/assets/js/transitions.min.js') ? 'transitions.min.js' : 'transitions.js';
    wp_enqueue_script('iran-map-transitions', IRAN_MAP_URL . '/assets/js/' . $trans_js, [], IRAN_MAP_VERSION, true);
    // Theme toggle + no flash - lightweight, always needed
    $theme_js = file_exists(IRAN_MAP_PATH . '/assets/js/theme.min.js') ? 'theme.min.js' : 'theme.js';
    wp_enqueue_script('iran-map-theme', IRAN_MAP_URL . '/assets/js/' . $theme_js, [], IRAN_MAP_VERSION, true);
});

// Preload Vazirmatn FD fonts - subset, only Regular + Bold (Step 8 perf)
add_action('wp_head', function() {
    // Check if subset exists, else fallback
    $regular = file_exists(IRAN_MAP_PATH . '/assets/fonts/Vazirmatn-FD-Regular-subset.woff2') ? 'Vazirmatn-FD-Regular-subset.woff2' : 'Vazirmatn-FD-Regular.woff2';
    $bold = file_exists(IRAN_MAP_PATH . '/assets/fonts/Vazirmatn-FD-Bold-subset.woff2') ? 'Vazirmatn-FD-Bold-subset.woff2' : 'Vazirmatn-FD-Bold.woff2';
    $fonts = [$regular, $bold];
    foreach ($fonts as $font) {
        $url = IRAN_MAP_URL . '/assets/fonts/' . $font;
        printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url($url));
    }
    // Preconnect optimization
    echo '<link rel="preconnect" href="' . esc_url(home_url()) . '" crossorigin>' . "\n";
}, 1);

// Cache headers for static assets - SVG Brotli/gzip, 1y woff2/svg
add_action('send_headers', function() {
    if (is_admin()) return;
    // Add cache control for theme assets via .htaccess, but also via headers for PHP-served SVG
    if (strpos($_SERVER['REQUEST_URI'] ?? '', '.svg') !== false) {
        header('Content-Type: image/svg+xml');
        header('Cache-Control: public, max-age=31536000, immutable');
        header('Vary: Accept-Encoding');
    }
});

// Defer non-critical JS for performance
add_filter('script_loader_tag', function($tag, $handle) {
    if (in_array($handle, ['iran-map-map', 'iran-map-coloring', 'iran-map-transitions', 'iran-map-theme'])) {
        // Already in footer, add defer for non-map
        if ($handle !== 'iran-map-theme') {
            $tag = str_replace(' src', ' defer src', $tag);
        }
    }
    return $tag;
}, 10, 2);

// RTL and language handling
add_filter('language_attributes', function($output) {
    if (strpos($output, 'dir=') === false && is_rtl()) {
        $output .= ' dir="rtl"';
    }
    return $output;
});

add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) return;
    $locale = get_locale();
    if ($locale !== 'fa_IR') {
        $screen = get_current_screen();
        if ($screen && $screen->id === 'themes') {
            echo '<div class="notice notice-info"><p>';
            echo esc_html__('پیشنهاد: زبان سایت را روی فارسی (fa_IR) تنظیم کنید تا تاریخ‌ها، جهت RTL و ترجمه‌ها درست کار کنند. مسیر: تنظیمات > عمومی > زبان سایت', 'iran-map');
            echo '</p></div>';
        }
    }
});

add_filter('body_class', function($classes) {
    if (is_rtl()) { $classes[] = 'rtl'; $classes[] = 'is-rtl'; }
    $classes[] = 'no-jquery';
    return $classes;
});

add_filter('excerpt_length', function($length) { return 30; });
remove_action('wp_head', 'wp_generator');

function iran_map_fallback_menu() {
    echo '<ul class="fallback-menu">';
    echo '<li><a href="' . esc_url(home_url('/')) . '">' . esc_html__('خانه', 'iran-map') . '</a></li>';
    $regions = get_posts([
        'post_type'   => 'region',
        'numberposts' => 10,
        'post_parent' => 0,
        'post_status' => 'publish',
        'orderby'     => 'title',
        'order'       => 'ASC',
    ]);
    foreach ($regions as $region) {
        echo '<li><a href="' . esc_url(get_permalink($region)) . '">' . esc_html($region->post_title) . '</a></li>';
    }
    echo '</ul>';
}

/* SEO - Step 6 */

// Ensure region CPT is in core sitemap
add_filter('wp_sitemaps_post_types', function($post_types) {
    $post_types['region'] = get_post_type_object('region');
    return $post_types;
});

// Helper to detect SEO plugins
function iran_map_has_seo_plugin() {
    return defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION') || class_exists('WPSEO_Frontend');
}

// Unique title, meta description, canonical, OG - only if no SEO plugin
add_action('wp_head', function() {
    if (iran_map_has_seo_plugin()) return; // Let Rank Math/Yoast handle
    if (is_front_page()) return; // Let WP handle front page, but we add OG below

    if (is_singular('region')) {
        global $post;
        $summary = get_post_meta($post->ID, 'summary', true) ?: get_the_excerpt($post);
        $summary = wp_strip_all_tags($summary);
        $summary = mb_substr($summary, 0, 160);
        $canonical = get_permalink($post);
        $title = get_the_title($post) . ' - ' . get_bloginfo('name');
        // Title tag already handled by WP, but we ensure meta description
        echo '<meta name="description" content="' . esc_attr($summary) . '">' . "\n";
        echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
        // Open Graph
        $og_image = get_the_post_thumbnail_url($post, 'region-hero') ?: IRAN_MAP_URL . '/screenshot.png';
        echo '<meta property="og:type" content="place">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($summary) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url($canonical) . '">' . "\n";
        echo '<meta property="og:image" content="' . esc_url($og_image) . '">' . "\n";
        echo '<meta property="og:locale" content="fa_IR">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . '">' . "\n";
    }
}, 5);

// If Rank Math / Yoast active, use their filters
add_filter('rank_math/frontend/title', function($title) {
    if (is_singular('region')) {
        $post = get_queried_object();
        if ($post) {
            $summary = get_post_meta($post->ID, 'summary', true);
            // Keep title but ensure unique
            return $post->post_title . ' | ' . get_bloginfo('name') . ' - نقشه ایران';
        }
    }
    return $title;
});
add_filter('rank_math/frontend/description', function($desc) {
    if (is_singular('region')) {
        $post = get_queried_object();
        if ($post) {
            $summary = get_post_meta($post->ID, 'summary', true) ?: get_the_excerpt($post);
            return wp_strip_all_tags(mb_substr($summary, 0, 160));
        }
    }
    return $desc;
});
add_filter('wpseo_title', function($title) {
    if (is_singular('region')) {
        $post = get_queried_object();
        if ($post) return $post->post_title . ' | ' . get_bloginfo('name') . ' - نقشه ایران';
    }
    return $title;
});
add_filter('wpseo_metadesc', function($desc) {
    if (is_singular('region')) {
        $post = get_queried_object();
        if ($post) {
            $summary = get_post_meta($post->ID, 'summary', true) ?: get_the_excerpt($post);
            return wp_strip_all_tags(mb_substr($summary, 0, 160));
        }
    }
    return $desc;
});

// JSON-LD Place + BreadcrumbList
add_action('wp_head', function() {
    if (!is_singular('region')) return;
    global $post;
    $post_id = $post->ID;
    $is_province = ($post->post_parent == 0);
    $parent = $is_province ? null : get_post($post->post_parent);
    $summary = get_post_meta($post_id, 'summary', true) ?: get_the_excerpt($post);
    $summary = wp_strip_all_tags($summary);
    $area = get_post_meta($post_id, 'area_km2', true);
    $population = get_post_meta($post_id, 'population', true);
    $capital = get_post_meta($post_id, 'capital', true);
    $label_anchor = get_post_meta($post_id, 'label_anchor', true);
    $lon = $label_anchor['lon'] ?? null;
    $lat = $label_anchor['lat'] ?? null;

    // BreadcrumbList
    $breadcrumbs = [];
    $breadcrumbs[] = [
        '@type' => 'ListItem',
        'position' => 1,
        'name' => 'ایران',
        'item' => home_url('/')
    ];
    if ($parent) {
        $breadcrumbs[] = [
            '@type' => 'ListItem',
            'position' => 2,
            'name' => $parent->post_title,
            'item' => get_permalink($parent)
        ];
        $breadcrumbs[] = [
            '@type' => 'ListItem',
            'position' => 3,
            'name' => $post->post_title,
            'item' => get_permalink($post)
        ];
    } else {
        $breadcrumbs[] = [
            '@type' => 'ListItem',
            'position' => 2,
            'name' => $post->post_title,
            'item' => get_permalink($post)
        ];
    }

    $breadcrumb_ld = [
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        'itemListElement' => $breadcrumbs
    ];

    // Place
    $place = [
        '@context' => 'https://schema.org',
        '@type' => 'Place',
        'name' => $post->post_title,
        'description' => mb_substr($summary, 0, 200),
        'url' => get_permalink($post),
    ];
    if ($lon && $lat) {
        $place['geo'] = [
            '@type' => 'GeoCoordinates',
            'longitude' => $lon,
            'latitude' => $lat
        ];
    }
    if ($parent) {
        $place['containedInPlace'] = [
            '@type' => 'Place',
            'name' => $parent->post_title,
            'url' => get_permalink($parent)
        ];
    } else {
        $place['containedInPlace'] = [
            '@type' => 'Place',
            'name' => 'ایران',
            'url' => home_url('/')
        ];
    }
    if ($area) $place['additionalProperty'][] = ['@type' => 'PropertyValue', 'name' => 'area', 'value' => $area . ' km2'];
    if ($population) $place['additionalProperty'][] = ['@type' => 'PropertyValue', 'name' => 'population', 'value' => $population];
    if ($capital) $place['additionalProperty'][] = ['@type' => 'PropertyValue', 'name' => 'capital', 'value' => $capital];

    echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb_ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    echo '<script type="application/ld+json">' . wp_json_encode($place, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}, 20);

// Front page SEO list helper - get all regions for no-JS fallback
function iran_map_get_all_regions_for_list() {
    $regions = get_posts([
        'post_type' => 'region',
        'numberposts' => -1,
        'post_status' => 'publish',
        'orderby' => 'title',
        'order' => 'ASC',
    ]);
    if (!empty($regions)) return $regions;

    // Fallback to regions.json
    $json_paths = [
        IRAN_MAP_PATH . '/../../regions.json',
        '/home/user/MAP/regions.json',
        IRAN_MAP_PATH . '/assets/svg/regions.json',
    ];
    foreach ($json_paths as $p) {
        if (file_exists($p)) {
            $data = json_decode(file_get_contents($p), true);
            if (is_array($data)) return $data;
        }
    }
    return [];
}
