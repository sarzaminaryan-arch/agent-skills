        </div><!-- .container -->
    </main><!-- #primary -->
    <footer id="colophon" class="site-footer">
        <div class="container">
            <p>
                <?php
                printf(
                    esc_html__('© %1$s %2$s - نقشه تعاملی ایران', 'iran-map'),
                    esc_html(date_i18n('Y')),
                    esc_html(get_bloginfo('name'))
                );
                ?>
            </p>
            <nav aria-label="<?php esc_attr_e('منوی فوتر', 'iran-map'); ?>">
                <?php
                wp_nav_menu([
                    'theme_location' => 'footer',
                    'menu_id'        => 'footer-menu',
                    'depth'          => 1,
                    'fallback_cb'    => false,
                    'container'      => false,
                ]);
                ?>
            </nav>
        </div>
    </footer>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
