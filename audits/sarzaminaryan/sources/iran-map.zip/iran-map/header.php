<!doctype html>
<html <?php language_attributes(); ?> dir="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="view-transition" content="same-origin" />
    <meta name="color-scheme" content="light dark" />
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <script>
        // Step 7: Dark mode - no flash of wrong theme (inline script in head)
        (function() {
            try {
                var saved = localStorage.getItem('iran-map-theme');
                var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
                var theme = saved || (prefersDark ? 'dark' : 'light');
                document.documentElement.setAttribute('data-theme', theme);
                // Also set color-scheme for browser UI
                document.documentElement.style.colorScheme = theme;
            } catch(e) {}
        })();
    </script>
    <style>
        /* View Transitions API - cross-document */
        @view-transition {
            navigation: auto;
        }
        ::view-transition-old(root),
        ::view-transition-new(root) {
            animation-duration: 0.3s;
            animation-timing-function: ease-in-out;
        }
        /* Fade fallback for browsers without View Transitions */
        @supports not (view-transition-name: root) {
            body {
                opacity: 1;
                transition: opacity 0.2s ease-out;
            }
            body.is-exiting {
                opacity: 0;
            }
        }
        /* Prevent flash - hide body until theme set */
        html[data-theme] body {
            opacity: 1;
        }
    </style>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
    <a class="screen-reader-text" href="#primary"><?php esc_html_e('پرش به محتوا', 'iran-map'); ?></a>
    <header id="masthead" class="site-header">
        <div class="container">
            <div class="site-branding">
                <?php if (has_custom_logo()): ?>
                    <?php the_custom_logo(); ?>
                <?php else: ?>
                    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home" style="view-transition-name: site-title;"><?php bloginfo('name'); ?></a>
                    <?php
                    $desc = get_bloginfo('description', 'display');
                    if ($desc) {
                        echo '<p class="site-description" style="margin:0;font-size:0.875rem;color:var(--color-text-tertiary);">' . esc_html($desc) . '</p>';
                    }
                    ?>
                <?php endif; ?>
            </div>
            <nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e('منوی اصلی', 'iran-map'); ?>">
                <?php
                wp_nav_menu([
                    'theme_location' => 'primary',
                    'menu_id'        => 'primary-menu',
                    'fallback_cb'    => 'iran_map_fallback_menu',
                    'container'      => false,
                ]);
                ?>
                <button id="iran-map-theme-toggle" class="iran-map-theme-toggle" type="button" aria-label="<?php esc_attr_e('تغییر تم', 'iran-map'); ?>" title="<?php esc_attr_e('تغییر تم روشن/تاریک', 'iran-map'); ?>">
                    <span class="theme-icon-light" aria-hidden="true">☀️</span>
                    <span class="theme-icon-dark" aria-hidden="true" style="display:none;">🌙</span>
                </button>
            </nav>
        </div>
    </header>
    <main id="primary" class="site-main">
        <div class="container">
