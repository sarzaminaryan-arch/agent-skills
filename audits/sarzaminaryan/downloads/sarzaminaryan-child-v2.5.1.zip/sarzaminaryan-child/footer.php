<?php
/**
 * Footer — Sarzamin Aryan Child.
 *
 * v2.4.0 — جمع‌وجور شد. نسخه‌ی قبل چهار ستون و ~۲۰ لینک داشت که نیمی‌شان تکراری
 * بودند (درباره ما، تماس با ما و سیاست تحریریه دو بار می‌آمدند) و به آرشیوهای
 * خالی هم لینک می‌داد. حالا سه ستون، بدون تکرار:
 *   برند + معرفی کوتاه  ·  کاوش (استان‌ها، شهرها)  ·  درباره/تماس/سیاست
 *
 * @package Sarzaminaryan_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sa_logo_url = SA_CHILD_URI . 'assets/img/logo.webp';
if ( has_custom_logo() ) {
	$sa_logo_id = (int) get_theme_mod( 'custom_logo' );
	$sa_logo    = wp_get_attachment_image_src( $sa_logo_id, 'full' );
	if ( $sa_logo ) {
		$sa_logo_url = $sa_logo[0];
	}
}
$sa_slogan = get_theme_mod( 'sa_home_slogan', 'چو ایران نباشد، تن من مباد' );

/**
 * لینک یکی از برگه‌های ثابت — رشته‌ی خالی اگر برگه وجود نداشته باشد یا منتشر نشده باشد.
 *
 * v2.3.0: قبلاً وقتی برگه پیدا نمی‌شد یک نشانی حدسی برمی‌گرداند، یعنی فوتر هر
 * صفحه‌ی سایت به یک ۴۰۴ لینک می‌داد.
 *
 * @param string $slug نامک برگه.
 * @return string
 */
function sa_seeded_page_link( $slug ) {
	$sa_ids = get_option( 'sa_default_pages', array() );
	if ( ! empty( $sa_ids[ $slug ] ) ) {
		$sa_post = get_post( (int) $sa_ids[ $slug ] );
		if ( $sa_post && 'publish' === $sa_post->post_status ) {
			return get_permalink( $sa_post );
		}
	}
	$sa_page = get_page_by_path( $slug );
	if ( $sa_page instanceof WP_Post && 'publish' === $sa_page->post_status ) {
		return get_permalink( $sa_page );
	}
	return '';
}
?>

<footer id="colophon" class="site-footer sa-foot">
	<div class="container">

		<div class="sa-foot__grid">

			<div class="sa-foot__col sa-foot__brand">
				<a class="sa-foot__logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					<span class="sa-foot__logo"><img src="<?php echo esc_url( $sa_logo_url ); ?>" width="96" height="96" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" loading="lazy" decoding="async"></span>
					<span class="sa-foot__names">
						<span class="sa-foot__title"><?php bloginfo( 'name' ); ?></span>
						<span class="sa-foot__slogan"><?php echo esc_html( $sa_slogan ); ?></span>
					</span>
				</a>
				<p class="sa-foot__about"><?php echo esc_html( get_theme_mod( 'sa_footer_about', 'دانشنامه‌ی سفر ایران؛ استان به استان، شهر به شهر.' ) ); ?></p>
			</div>

			<nav class="sa-foot__col" aria-label="کاوش در ایران">
				<h2 class="sa-foot__head">کاوش در ایران</h2>
				<ul class="sa-foot__links">
					<li><a href="<?php echo esc_url( sa_archive_url( 'province' ) ); ?>">استان‌ها</a></li>
					<li><a href="<?php echo esc_url( sa_archive_url( 'city' ) ); ?>">شهرها</a></li>
				</ul>
			</nav>

			<nav class="sa-foot__col" aria-label="درباره‌ی سایت">
				<h2 class="sa-foot__head">درباره‌ی سایت</h2>
				<ul class="sa-foot__links">
					<?php
					$sa_pages = array(
						'about'   => 'درباره ما',
						'contact' => 'تماس با ما',
						'privacy' => 'حریم خصوصی',
						'policy'  => 'سیاست تحریریه',
					);
					$sa_any   = false;
					foreach ( $sa_pages as $sa_slug => $sa_label ) :
						$sa_url = sa_seeded_page_link( $sa_slug );
						if ( ! $sa_url ) :
							continue;
						endif;
						$sa_any = true;
						?>
						<li><a href="<?php echo esc_url( $sa_url ); ?>"><?php echo esc_html( $sa_label ); ?></a></li>
						<?php
					endforeach;
					$sa_mail = get_theme_mod( 'sa_contact_email', '' );
					if ( $sa_mail ) :
						?>
						<li><a href="mailto:<?php echo esc_attr( antispambot( $sa_mail ) ); ?>"><?php echo esc_html( antispambot( $sa_mail ) ); ?></a></li>
						<?php
						$sa_any = true;
					endif;
					if ( ! $sa_any ) :
						?>
						<li class="sa-foot__muted">به‌زودی</li>
					<?php endif; ?>
				</ul>
			</nav>

		</div>

		<div class="sa-foot__bottom">
			<p>
				<?php
				$sa_copy = get_theme_mod( 'sa_footer_copyright', '' );
				if ( $sa_copy ) {
					echo esc_html( $sa_copy );
				} else {
					printf( '© %s %s', esc_html( sa_jalali_year() ), esc_html( get_bloginfo( 'name' ) ) );
				}
				?>
			</p>
			<?php if ( get_theme_mod( 'sa_footer_credit', true ) ) : ?>
				<p class="sa-foot__credit">طراحی و توسعه: محمدرضا لک</p>
			<?php endif; ?>
		</div>

	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
