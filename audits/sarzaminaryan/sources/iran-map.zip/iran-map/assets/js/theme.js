/**
 * Step 7: Dark mode - prefers-color-scheme + manual toggle, saved choice, no flash
 * - Inline script in head already sets data-theme to prevent flash
 * - This script handles toggle button, saves choice, updates icons, respects WCAG AA
 */
(function() {
    'use strict';

    function initTheme() {
        const toggle = document.getElementById('iran-map-theme-toggle');
        const html = document.documentElement;

        function getSavedTheme() {
            try {
                return localStorage.getItem('iran-map-theme');
            } catch(e) { return null; }
        }
        function saveTheme(theme) {
            try { localStorage.setItem('iran-map-theme', theme); } catch(e) {}
        }
        function applyTheme(theme) {
            html.setAttribute('data-theme', theme);
            html.style.colorScheme = theme;
            saveTheme(theme);
            updateToggleIcon(theme);
            // Dispatch event for other components (e.g., map)
            window.dispatchEvent(new CustomEvent('iran-map-theme-change', { detail: { theme } }));
        }
        function updateToggleIcon(theme) {
            if (!toggle) return;
            const lightIcon = toggle.querySelector('.theme-icon-light');
            const darkIcon = toggle.querySelector('.theme-icon-dark');
            if (theme === 'dark') {
                if (lightIcon) lightIcon.style.display = 'none';
                if (darkIcon) darkIcon.style.display = 'inline';
                toggle.setAttribute('aria-label', 'تغییر به تم روشن');
                toggle.title = 'تغییر به تم روشن';
            } else {
                if (lightIcon) lightIcon.style.display = 'inline';
                if (darkIcon) darkIcon.style.display = 'none';
                toggle.setAttribute('aria-label', 'تغییر به تم تاریک');
                toggle.title = 'تغییر به تم تاریک';
            }
        }

        // Initial icon update
        const currentTheme = html.getAttribute('data-theme') || 'light';
        updateToggleIcon(currentTheme);

        if (toggle) {
            toggle.addEventListener('click', () => {
                const current = html.getAttribute('data-theme') || 'light';
                const next = current === 'dark' ? 'light' : 'dark';
                applyTheme(next);
            });
        }

        // Listen for system preference changes if no saved choice
        if (window.matchMedia) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            mediaQuery.addEventListener('change', (e) => {
                const saved = getSavedTheme();
                if (!saved) {
                    applyTheme(e.matches ? 'dark' : 'light');
                }
            });
        }

        // Expose for debugging
        window.IranMapTheme = {
            applyTheme,
            getCurrentTheme: () => html.getAttribute('data-theme'),
            toggle: () => {
                const cur = html.getAttribute('data-theme') || 'light';
                applyTheme(cur === 'dark' ? 'light' : 'dark');
            }
        };
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTheme);
    } else {
        initTheme();
    }
})();
