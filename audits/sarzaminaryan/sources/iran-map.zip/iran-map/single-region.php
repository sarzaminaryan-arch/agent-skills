<?php
/**
 * Single region template - Step 6: Province and county templates with SEO
 * - Full-width hero image (AVIF/WebP, srcset, LCP not lazy, placeholder if none)
 * - Breadcrumb (Iran > Isfahan > Kashan, Persian RTL)
 * - Quick-facts strip from meta
 * - Description
 * - Child-county grid (provinces only)
 * - Mini-map highlighting current region (static inline SVG, links to map state)
 * - Neighbors section
 * - JSON-LD handled in functions.php
 */
get_header();

while (have_posts()): the_post();
    $post_id = get_the_ID();
    $svg_id = get_post_meta($post_id, 'svg_id', true);
    $population = get_post_meta($post_id, 'population', true);
    $area_km2 = get_post_meta($post_id, 'area_km2', true);
    $climate = get_post_meta($post_id, 'climate', true);
    $hero_image_id = get_post_meta($post_id, 'hero_image', true);
    $summary = get_post_meta($post_id, 'summary', true);
    $neighbors_raw = get_post_meta($post_id, 'neighbors', true);
    $capital = get_post_meta($post_id, 'capital', true);
    $original_id = get_post_meta($post_id, 'original_id', true);
    $bbox = get_post_meta($post_id, 'bbox', true);
    $label_anchor = get_post_meta($post_id, 'label_anchor', true);
    $slug_en = get_post_meta($post_id, 'slug_en', true) ?: $post->post_name;
    $parent_slug = get_post_meta($post_id, 'parent_slug', true);

    $is_province = ($post->post_parent == 0);
    $parent_post = $is_province ? null : get_post($post->post_parent);
    $parent_slug_en = $parent_post ? get_post_meta($parent_post->ID, 'slug_en', true) ?: $parent_post->post_name : $parent_slug;

    // Hero image: try featured image, then hero_image meta, else placeholder
    $hero_id = has_post_thumbnail($post_id) ? get_post_thumbnail_id($post_id) : ($hero_image_id ? intval($hero_image_id) : 0);
    $hero_src = $hero_id ? wp_get_attachment_image_url($hero_id, 'region-hero') : '';
    $hero_src_2x = $hero_id ? wp_get_attachment_image_url($hero_id, 'region-hero-2x') : '';
    $hero_alt = $hero_id ? get_post_meta($hero_id, '_wp_attachment_image_alt', true) : '';
    if (!$hero_alt) $hero_alt = get_the_title();

    // Child counties for province
    $children = [];
    if ($is_province) {
        $children = get_children([
            'post_parent' => $post_id,
            'post_type'   => 'region',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby'     => 'title',
            'order'       => 'ASC',
        ]);
    }

    // Neighbors parsing - split by comma or ،
    $neighbors_list = [];
    if ($neighbors_raw) {
        $parts = preg_split('/[،,]/u', $neighbors_raw);
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p) $neighbors_list[] = $p;
        }
    }

    // Mini-map: load SVG
    $mini_map_svg = '';
    $mini_map_type = $is_province ? 'iran' : 'province';
    $mini_map_highlight_slug = $slug_en;

    // Try to load appropriate SVG for mini-map
    $svg_paths_to_try = [];
    if ($is_province) {
        $svg_paths_to_try = [
            get_template_directory() . '/assets/svg/iran-provinces.svg',
            IRAN_MAP_PATH . '/../../iran-provinces.svg',
            '/home/user/MAP/iran-provinces.svg',
        ];
    } else {
        // For county, load parent province counties SVG
        $parent_for_svg = $parent_slug_en ?: $parent_slug;
        if ($parent_for_svg) {
            $svg_paths_to_try = [
                get_template_directory() . '/assets/svg/counties/' . $parent_for_svg . '.svg',
                IRAN_MAP_PATH . '/../../counties/' . $parent_for_svg . '.svg',
                '/home/user/MAP/counties/' . $parent_for_svg . '.svg',
            ];
        }
    }

    $mini_map_content = '';
    foreach ($svg_paths_to_try as $svg_path) {
        if (file_exists($svg_path)) {
            $mini_map_content = file_get_contents($svg_path);
            break;
        }
    }

    // Breadcrumb data for JSON-LD already handled in functions.php, but we need HTML breadcrumb
?>

    <!-- Hero - full-width, AVIF/WebP srcset, LCP not lazy, placeholder if none -->
    <div class="region-hero" style="view-transition-name: hero-<?php echo esc_attr($post_id); ?>">
        <?php if ($hero_id && $hero_src): ?>
            <picture>
                <?php
                // AVIF and WebP sources - WordPress may generate these if supported, we try to get them
                $avif_src = wp_get_attachment_image_url($hero_id, 'region-hero', false);
                // Replace extension with avif/webp if exists? For simplicity, we output same src with type, browser will handle via srcset if available
                // We also get srcset which will include WebP/AVIF if generated
                $srcset = wp_get_attachment_image_srcset($hero_id, 'region-hero');
                $srcset_2x = wp_get_attachment_image_srcset($hero_id, 'region-hero-2x');
                $sizes = '(max-width: 768px) 100vw, 1200px';
                ?>
                <?php if ($srcset): ?>
                    <source type="image/avif" srcset="<?php echo esc_attr($srcset); ?><?php echo $srcset_2x ? ', ' . esc_attr($srcset_2x) . ' 2x' : ''; ?>" sizes="<?php echo esc_attr($sizes); ?>">
                    <source type="image/webp" srcset="<?php echo esc_attr($srcset); ?><?php echo $srcset_2x ? ', ' . esc_attr($srcset_2x) . ' 2x' : ''; ?>" sizes="<?php echo esc_attr($sizes); ?>">
                <?php endif; ?>
                <img src="<?php echo esc_url($hero_src); ?>"
                     srcset="<?php echo $srcset ? esc_attr($srcset) . ' 1x' : ''; ?><?php echo $srcset_2x ? ', ' . esc_attr($srcset_2x) . ' 2x' : ''; ?>"
                     sizes="<?php echo esc_attr($sizes); ?>"
                     alt="<?php echo esc_attr($hero_alt); ?>"
                     width="1200"
                     height="600"
                     fetchpriority="high"
                     decoding="async"
                     loading="eager"
                     style="view-transition-name: hero-image-<?php echo esc_attr($post_id); ?>" />
            </picture>
        <?php else: ?>
            <div class="region-hero-placeholder">
                <span>🖼️ <?php echo esc_html(get_the_title()); ?> - تصویر موجود نیست</span>
            </div>
        <?php endif; ?>
        <div class="region-hero-overlay">
            <h1><?php the_title(); ?></h1>
        </div>
    </div>

    <!-- Breadcrumb - Iran > Isfahan > Kashan, Persian RTL -->
    <nav class="breadcrumb" aria-label="<?php esc_attr_e('مسیر', 'iran-map'); ?>" dir="rtl">
        <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('ایران', 'iran-map'); ?></a>
        <span class="separator" aria-hidden="true">›</span>
        <?php if ($parent_post): ?>
            <a href="<?php echo esc_url(get_permalink($parent_post)); ?>"><?php echo esc_html($parent_post->post_title); ?></a>
            <span class="separator" aria-hidden="true">›</span>
            <span class="current" aria-current="page"><?php the_title(); ?></span>
        <?php else: ?>
            <span class="current" aria-current="page"><?php the_title(); ?></span>
        <?php endif; ?>
    </nav>

    <article id="post-<?php the_ID(); ?>" <?php post_class('single-region'); ?>>

        <!-- Quick-facts strip from meta -->
        <div class="region-quick-facts" aria-label="<?php esc_attr_e('اطلاعات سریع', 'iran-map'); ?>">
            <?php if ($capital): ?>
                <div class="region-quick-fact"><span class="label"><?php esc_html_e('مرکز', 'iran-map'); ?></span><span class="value"><?php echo esc_html($capital); ?></span></div>
            <?php endif; ?>
            <?php if ($population): ?>
                <div class="region-quick-fact"><span class="label"><?php esc_html_e('جمعیت', 'iran-map'); ?></span><span class="value"><?php echo esc_html(number_format_i18n($population)); ?></span></div>
            <?php endif; ?>
            <?php if ($area_km2): ?>
                <div class="region-quick-fact"><span class="label"><?php esc_html_e('مساحت', 'iran-map'); ?></span><span class="value"><?php echo esc_html($area_km2); ?> km²</span></div>
            <?php endif; ?>
            <?php if ($climate): ?>
                <div class="region-quick-fact"><span class="label"><?php esc_html_e('اقلیم', 'iran-map'); ?></span><span class="value"><?php echo esc_html($climate); ?></span></div>
            <?php endif; ?>
            <?php if ($original_id): ?>
                <div class="region-quick-fact"><span class="label"><?php esc_html_e('کد', 'iran-map'); ?></span><span class="value"><?php echo esc_html($original_id); ?></span></div>
            <?php endif; ?>
        </div>

        <!-- Description -->
        <div class="region-description">
            <?php if ($summary): ?>
                <p><strong><?php echo esc_html($summary); ?></strong></p>
            <?php endif; ?>
            <?php the_content(); ?>
            <?php if (!$summary && !get_the_content()): ?>
                <p><?php esc_html_e('توضیحی برای این منطقه ثبت نشده است.', 'iran-map'); ?></p>
            <?php endif; ?>
        </div>

        <!-- Mini-map highlighting current region (static inline SVG, links to map state) -->
        <?php if ($mini_map_content): ?>
            <div class="region-mini-map">
                <h3><?php esc_html_e('موقعیت روی نقشه', 'iran-map'); ?></h3>
                <?php
                // Parse SVG to highlight current and add links to map state
                $viewBox = '0 0 1000 920';
                if (preg_match('/viewBox="([^"]+)"/', $mini_map_content, $m)) $viewBox = $m[1];
                $paths = [];
                if (preg_match_all('/<path[^>]*id="([^"]+)"[^>]*data-slug="([^"]+)"[^>]*d="([^"]+)"[^>]*>/', $mini_map_content, $matches, PREG_SET_ORDER)) {
                    foreach ($matches as $match) $paths[] = ['id' => $match[1], 'slug' => $match[2], 'd' => $match[3]];
                } elseif (preg_match_all('/<path[^>]*id="([^"]+)"[^>]*d="([^"]+)"[^>]*>/', $mini_map_content, $matches2, PREG_SET_ORDER)) {
                    foreach ($matches2 as $match) {
                        $id = $match[1]; $slug = $id;
                        if (strpos($id, 'province-') === 0) $slug = substr($id, 9);
                        elseif (strpos($id, 'county-') === 0) { $parts = explode('-', $id); $slug = end($parts); }
                        $paths[] = ['id' => $id, 'slug' => $slug, 'd' => $match[2]];
                    }
                }
                ?>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="<?php echo esc_attr($viewBox); ?>" role="img" aria-label="<?php esc_attr_e('نقشه کوچک', 'iran-map'); ?>" shape-rendering="geometricPrecision">
                    <defs>
                        <filter id="mini-map-shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#000" flood-opacity="0.2"/></filter>
                    </defs>
                    <?php foreach ($paths as $p):
                        $is_current = ($p['slug'] === $mini_map_highlight_slug);
                        $cls = $is_current ? 'province is-current' : 'province';
                        if (!$is_province) $cls = $is_current ? 'county is-current' : 'county';
                        // Link to map state hash
                        if ($is_province) {
                            $hash_href = home_url('/#/'. $p['slug']);
                        } else {
                            // County mini-map: parent province + county
                            $parent_for_link = $parent_slug_en ?: $parent_slug;
                            $hash_href = $parent_for_link ? home_url('/#/'. $parent_for_link . '/' . $p['slug']) : home_url('/#/'. $p['slug']);
                        }
                        // Current region should not link to itself? But we link to map state still
                        ?>
                        <a href="<?php echo esc_url($hash_href); ?>" aria-label="<?php echo esc_attr($p['slug']); ?>">
                            <path id="<?php echo esc_attr($p['id']); ?>" data-slug="<?php echo esc_attr($p['slug']); ?>" class="<?php echo esc_attr($cls); ?>" d="<?php echo esc_attr($p['d']); ?>" vector-effect="non-scaling-stroke" shape-rendering="geometricPrecision" />
                        </a>
                    <?php endforeach; ?>
                </svg>
                <p style="font-size:12px;color:#666;margin-block-start:8px;">
                    <?php if ($is_province): ?>
                        <?php esc_html_e('نقشه ایران - استان فعلی با طلایی مشخص شده. روی هر استان کلیک کنید تا به حالت نقشه بروید.', 'iran-map'); ?>
                    <?php else: ?>
                        <?php printf(esc_html__('نقشه %s - شهرستان فعلی طلایی. کلیک برای رفتن به حالت نقشه.', 'iran-map'), esc_html($parent_post ? $parent_post->post_title : '')); ?>
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>

        <!-- Child-county grid (provinces only) -->
        <?php if ($is_province && $children): ?>
            <section class="region-children" aria-label="<?php esc_attr_e('شهرستان‌ها', 'iran-map'); ?>">
                <h2><?php echo esc_html(sprintf(__('شهرستان‌های %s (%d)', 'iran-map'), get_the_title(), count($children))); ?></h2>
                <div class="region-grid">
                    <?php foreach ($children as $child):
                        $child_summary = get_post_meta($child->ID, 'summary', true);
                        $child_area = get_post_meta($child->ID, 'area_km2', true);
                        $child_pop = get_post_meta($child->ID, 'population', true);
                        ?>
                        <article class="region-card" style="--vt-name: card-<?php echo esc_attr($child->ID); ?>">
                            <h3><a href="<?php echo esc_url(get_permalink($child)); ?>"><?php echo esc_html($child->post_title); ?></a></h3>
                            <?php if ($child_summary): ?><p><?php echo esc_html($child_summary); ?></p><?php endif; ?>
                            <div class="region-meta" style="margin-block-start:8px;">
                                <?php if ($child_area): ?><span>مساحت: <?php echo esc_html($child_area); ?> km²</span><?php endif; ?>
                                <?php if ($child_pop): ?><span>جمعیت: <?php echo esc_html(number_format_i18n($child_pop)); ?></span><?php endif; ?>
                            </div>
                            <a href="<?php echo esc_url(home_url('/#/' . $slug_en . '/' . $child->post_name)); ?>" style="font-size:12px;color:#888;margin-block-start:8px;display:inline-block;"><?php esc_html_e('نمایش روی نقشه', 'iran-map'); ?> ↗</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <!-- Neighbors section -->
        <?php if ($neighbors_list): ?>
            <section class="region-neighbors" aria-label="<?php esc_attr_e('همسایگان', 'iran-map'); ?>">
                <h3><?php esc_html_e('همسایگان', 'iran-map'); ?></h3>
                <div class="region-neighbors-list">
                    <?php foreach ($neighbors_list as $neighbor_name):
                        // Try to find neighbor post by title
                        $neighbor_post = get_page_by_title($neighbor_name, OBJECT, 'region');
                        if ($neighbor_post) {
                            echo '<a href="' . esc_url(get_permalink($neighbor_post)) . '">' . esc_html($neighbor_name) . '</a>';
                        } else {
                            // Try to find by slug from regions.json
                            $found = false;
                            foreach (glob(get_template_directory() . '/../../regions.json') as $jf) {}
                            // Fallback just text
                            echo '<span style="display:inline-flex;padding:6px 12px;background:#f5f5f5;border:1px solid #eee;border-radius:20px;font-size:13px;">' . esc_html($neighbor_name) . '</span>';
                        }
                    endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <p style="margin-block-start:2rem;font-size:13px;color:#666;">
            <em><?php esc_html_e('آدرس این صفحه به صورت /استان/ یا /استان/شهرستان/ است، مثلاً /isfahan/ یا /isfahan/kashan/. حالت تعاملی نقشه با hash است: /#/isfahan/kashan', 'iran-map'); ?></em>
        </p>

    </article>

<?php endwhile;

get_footer();
