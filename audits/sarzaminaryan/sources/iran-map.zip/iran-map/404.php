<?php
get_header();
?>
<h1><?php esc_html_e('صفحه یافت نشد (۴۰۴)', 'iran-map'); ?></h1>
<p><?php esc_html_e('متأسفانه صفحه مورد نظر شما وجود ندارد.', 'iran-map'); ?></p>
<p><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('بازگشت به خانه', 'iran-map'); ?></a></p>
<?php
get_footer();
