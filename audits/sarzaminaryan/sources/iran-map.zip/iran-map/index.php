<?php
/**
 * Fallback index template
 */
get_header();
?>
<h1><?php esc_html_e('آخرین مطالب', 'iran-map'); ?></h1>
<?php if (have_posts()): ?>
    <div class="region-grid">
        <?php while (have_posts()): the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('region-card'); ?>>
                <h2><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title(); ?></a></h2>
                <div class="entry-excerpt">
                    <?php the_excerpt(); ?>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
    <?php the_posts_pagination(); ?>
<?php else: ?>
    <p><?php esc_html_e('محتوایی یافت نشد.', 'iran-map'); ?></p>
<?php endif; ?>
<?php
get_footer();
