<?php
/**
 * Archive for region CPT - lists provinces
 */
get_header();
?>
<h1><?php esc_html_e('همه مناطق ایران', 'iran-map'); ?></h1>

<?php
// List provinces (parent=0)
$provinces = get_posts([
    'post_type'   => 'region',
    'numberposts' => -1,
    'post_parent' => 0,
    'post_status' => 'publish',
    'orderby'     => 'title',
    'order'       => 'ASC',
]);

if ($provinces):
?>
    <div class="region-grid">
        <?php foreach ($provinces as $prov): ?>
            <article class="region-card">
                <h2><a href="<?php echo esc_url(get_permalink($prov)); ?>"><?php echo esc_html($prov->post_title); ?></a></h2>
                <p><?php echo esc_html(get_post_meta($prov->ID, 'summary', true)); ?></p>
            </article>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p><?php esc_html_e('منطقه‌ای یافت نشد.', 'iran-map'); ?></p>
<?php endif; ?>

<?php
get_footer();
