/**
 * Step 5: Panel, URL state and search
 * - Desktop 60/40, tablet stacked, mobile bottom sheet 3 snap points, map re-centers so region not hidden
 * - History API pushState/popstate with hash /#/isfahan/kashan, back/forward/refresh/cold deep link restore
 * - Instant autocomplete 479 names: Persian normalization ي→ی, ك→ک, ZWNJ, Arabic/Persian digits, prefix+substring, provinces first, counties show province
 * - Accessible combobox, keyboard up/down/Enter/Esc, selecting runs zoom animation
 * - Focus management: focus into panel on open, returns to region on close
 * - Extends Step 4 functionality
 */
(function() {
    'use strict';

    function initIranMap() {
        const container = document.getElementById('iran-map-container');
        const layout = document.getElementById('iran-map-layout');
        if (!container) return;
        const svg = container.querySelector('svg');
        const gMap = svg ? svg.querySelector('#map-group') : null;
        const provincesGroup = svg ? svg.querySelector('#provinces-group') : null;
        const countiesGroup = svg ? svg.querySelector('#counties-group') : null;
        const rippleGroup = svg ? svg.querySelector('#ripple-group') : null;
        const bgRect = svg ? svg.querySelector('#iran-map-bg') : null;
        const tooltip = document.getElementById('iran-map-tooltip');
        const loadingEl = document.getElementById('iran-map-loading');
        const regionsDataEl = document.getElementById('iran-regions-data');
        const configEl = document.getElementById('iran-map-config');
        const panel = document.getElementById('iran-map-panel');
        const panelHandle = document.getElementById('iran-map-panel-handle');
        const panelClose = document.getElementById('iran-map-panel-close');
        const panelTitle = document.getElementById('iran-map-panel-title');
        const panelSummary = document.getElementById('iran-map-panel-summary');
        const panelStats = document.getElementById('iran-map-panel-stats');
        const panelLink = document.getElementById('iran-map-panel-link');
        const panelImg = document.getElementById('iran-map-panel-img');
        const searchInput = document.getElementById('iran-map-search');
        const searchList = document.getElementById('iran-map-search-list');
        const searchClear = document.getElementById('iran-map-search-clear');
        const searchStatus = document.getElementById('iran-map-search-status');

        if (!svg || !gMap || !provincesGroup || !countiesGroup || !panel) return;

        // Config
        let initialViewBoxStr = container.dataset.initialViewbox || svg.getAttribute('viewBox') || '0 0 1000 920';
        if (configEl) {
            try {
                const cfg = JSON.parse(configEl.textContent);
                if (cfg.initialViewBox) initialViewBoxStr = cfg.initialViewBox;
            } catch(e) {}
        }
        function parseVB(str) {
            const p = str.trim().split(/[\s,]+/).map(Number);
            return { x: p[0]||0, y: p[1]||0, w: p[2]||1000, h: p[3]||920 };
        }
        function vbToStr(vb) { return `${vb.x} ${vb.y} ${vb.w} ${vb.h}`; }
        const baseVB = parseVB(initialViewBoxStr);
        let currentVB = { ...baseVB };
        const minZoom = 1, maxZoom = 8;
        let currentZoom = 1;

        // Regions data
        let regionsData = [];
        if (regionsDataEl) {
            try { regionsData = JSON.parse(regionsDataEl.textContent); } catch(e) {}
        }
        const regionBySlug = {};
        const provinceBySlug = {};
        const countyBySlug = {};
        regionsData.forEach(r => {
            if (r.slug_en) regionBySlug[r.slug_en] = r;
            if (r.svg_id) regionBySlug[r.svg_id] = r;
            if (r.type === 'province' && r.slug_en) provinceBySlug[r.slug_en] = r;
            if (r.type === 'county' && r.slug_en) {
                // County slug may not be unique across provinces, use parent_slug+slug as key
                countyBySlug[r.slug_en] = r;
                countyBySlug[`${r.parent_slug}/${r.slug_en}`] = r;
            }
        });

        // County cache
        const countyCache = new Map();
        let countiesBaseUrl = '/wp-content/themes/iran-map/assets/svg/counties/';
        if (configEl) {
            try { const cfg = JSON.parse(configEl.textContent); if (cfg.countiesBaseUrl) countiesBaseUrl = cfg.countiesBaseUrl; } catch(e) {}
        }

        // State
        let focusedSlug = null;
        let focusedCountySlug = null;
        let hoveredSlug = null;
        let isAnimating = false;
        let animFrame = null;
        let animStartTime = 0;
        let animFrom = null;
        let animTo = null;
        let animDuration = 700;
        let animOnComplete = null;
        let currentTransform = { x: 0, y: 0, scale: 1 };
        let lastTap = { slug: null, time: 0 };
        let isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
        let lastFocusedElement = null;
        let isUpdatingHash = false;
        let panelSnap = 'half'; // peek, half, full

        const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        // Helpers
        function clampVB(vb) {
            const minW = baseVB.w / maxZoom, maxW = baseVB.w / minZoom;
            const minH = baseVB.h / maxZoom, maxH = baseVB.h / minZoom;
            if (vb.w < minW) { const cx = vb.x + vb.w/2; vb.w = minW; vb.x = cx - vb.w/2; }
            if (vb.w > maxW) { const cx = vb.x + vb.w/2; vb.w = maxW; vb.x = cx - vb.w/2; }
            if (vb.h < minH) { const cy = vb.y + vb.h/2; vb.h = minH; vb.y = cy - vb.h/2; }
            if (vb.h > maxH) { const cy = vb.y + vb.h/2; vb.h = maxH; vb.y = cy - vb.h/2; }
            const maxPanX = baseVB.w * 0.5, maxPanY = baseVB.h * 0.5;
            const minX = baseVB.x - maxPanX, maxX = baseVB.x + baseVB.w + maxPanX - vb.w;
            const minY = baseVB.y - maxPanY, maxY = baseVB.y + baseVB.h + maxPanY - vb.h;
            vb.x = Math.max(minX, Math.min(maxX, vb.x));
            vb.y = Math.max(minY, Math.min(maxY, vb.y));
            return vb;
        }
        function vbToTransform(vb) {
            const s = baseVB.w / vb.w;
            const tx = baseVB.x - vb.x * s;
            const ty = baseVB.y - vb.y * s;
            return { x: tx, y: ty, scale: s };
        }
        function applyTransform(tr) {
            currentTransform = { ...tr };
            gMap.style.transform = `translate3d(${tr.x}px, ${tr.y}px, 0) scale(${tr.scale})`;
            gMap.style.transformOrigin = '0 0';
        }
        function resetTransformToVB(vb) {
            currentVB = clampVB({ ...vb });
            svg.setAttribute('viewBox', vbToStr(currentVB));
            currentTransform = { x: 0, y: 0, scale: 1 };
            gMap.style.transform = '';
            currentZoom = baseVB.w / currentVB.w;
            updateLabels();
        }
        function easeInOutCubic(t) {
            return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        }
        function cancelAnimation() {
            if (animFrame) { cancelAnimationFrame(animFrame); animFrame = null; }
            isAnimating = false;
        }
        function animateTransform(from, to, duration, onUpdate, onComplete) {
            if (prefersReducedMotion) {
                applyTransform(to);
                if (onUpdate) onUpdate(to, 1);
                if (onComplete) onComplete();
                return;
            }
            cancelAnimation();
            isAnimating = true;
            animFrom = { ...from };
            animTo = { ...to };
            animDuration = duration;
            animStartTime = performance.now();
            function step(now) {
                const elapsed = now - animStartTime;
                let progress = Math.min(elapsed / animDuration, 1);
                const eased = easeInOutCubic(progress);
                const cur = {
                    x: animFrom.x + (animTo.x - animFrom.x) * eased,
                    y: animFrom.y + (animTo.y - animFrom.y) * eased,
                    scale: animFrom.scale + (animTo.scale - animFrom.scale) * eased
                };
                applyTransform(cur);
                if (onUpdate) onUpdate(cur, progress);
                if (progress < 1) animFrame = requestAnimationFrame(step);
                else { isAnimating = false; animFrame = null; if (onComplete) onComplete(); }
            }
            animFrame = requestAnimationFrame(step);
        }

        // Labels
        const labels = svg.querySelectorAll('.iran-map-label');
        const tapZones = svg.querySelectorAll('.iran-map-tap-zone');
        labels.forEach(label => {
            const cs = window.getComputedStyle(label);
            label.dataset.initialFontSize = parseFloat(cs.fontSize) || 14;
        });
        function updateLabels() {
            const isMobile = window.innerWidth <= 480;
            const minFS = isMobile ? 12 : 10;
            labels.forEach(label => {
                const init = parseFloat(label.dataset.initialFontSize) || 14;
                let ns = init / currentZoom;
                const svgW = svg.clientWidth || 1000;
                const req = minFS * (currentVB.w / svgW);
                if (ns < req) ns = req;
                label.style.fontSize = ns + 'px';
            });
            tapZones.forEach(zone => {
                const svgW = svg.clientWidth || 1000;
                const r = 22 * (currentVB.w / svgW);
                if (zone.tagName === 'circle') zone.setAttribute('r', r);
            });
            requestAnimationFrame(() => {
                const sorted = Array.from(labels).sort((a,b) => (parseFloat(b.dataset.area)||0) - (parseFloat(a.dataset.area)||0));
                sorted.forEach(l => { l.style.display = ''; l.style.opacity = '1'; });
                let i = 0;
                function processChunk() {
                    const chunkSize = 10;
                    const end = Math.min(i+chunkSize, sorted.length);
                    for (; i < end; i++) {
                        const a = sorted[i]; if (a.style.display === 'none') continue;
                        const ra = a.getBoundingClientRect();
                        for (let j = i+1; j < sorted.length; j++) {
                            const b = sorted[j]; if (b.style.display === 'none') continue;
                            const rb = b.getBoundingClientRect();
                            const overlap = !(ra.right < rb.left || ra.left > rb.right || ra.bottom < rb.top || ra.top > rb.bottom);
                            if (overlap) {
                                if (currentZoom < 2) b.style.display = 'none';
                                else if (currentZoom < 4) {
                                    const xo = Math.max(0, Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left));
                                    const yo = Math.max(0, Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top));
                                    const oa = xo*yo, ma = Math.min(ra.width*ra.height, rb.width*rb.height);
                                    if (oa > ma*0.3) b.style.display = 'none';
                                }
                            }
                        }
                    }
                    if (i < sorted.length) requestAnimationFrame(processChunk);
                }
                processChunk();
            });
        }

        // Persian normalization
        function normalizePersian(str) {
            if (!str) return '';
            return str.toString()
                .replace(/ي/g, 'ی')
                .replace(/ك/g, 'ک')
                .replace(/ى/g, 'ی')
                .replace(/ٓ|ً|ٌ|ٍ|َ|ُ|ِ|ّ|ْ|ٕ|ٖ|ٗ|٘|ٙ|ٚ|ٛ|ٜ|ٝ|ٞ|ٟ/g, '')
                .replace(/\u200C/g, '')
                .replace(/\u200D/g, '')
                .replace(/[\u0640]/g, '')
                .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 0x0660 + 48))
                .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 0x06F0 + 48))
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
        }

        // Search index
        const searchIndex = [];
        regionsData.forEach(r => {
            if (!r.name_fa) return;
            const normalized = normalizePersian(r.name_fa);
            const normalizedEn = normalizePersian(r.slug_en || '');
            searchIndex.push({
                original: r,
                normalized,
                normalizedEn,
                type: r.type,
                slug: r.slug_en,
                parent: r.parent_slug || null,
                provinceName: r.parent_slug ? (provinceBySlug[r.parent_slug]?.name_fa || r.parent_slug) : null
            });
        });

        // Tooltip
        function formatNumber(num) { if (!num) return '-'; return Number(num).toLocaleString('fa-IR'); }
        function showTooltip(slug, clientX, clientY) {
            if (!tooltip) return;
            const rd = regionBySlug[slug]; if (!rd) return;
            const titleEl = tooltip.querySelector('.iran-map-tooltip-title');
            const areaEl = tooltip.querySelector('[data-stat="area"]');
            const popEl = tooltip.querySelector('[data-stat="population"]');
            const capEl = tooltip.querySelector('[data-stat="capital"]');
            if (titleEl) titleEl.textContent = rd.name_fa || slug;
            if (areaEl) areaEl.textContent = rd.area_km2 ? `${formatNumber(rd.area_km2)} km²` : '-';
            if (popEl) popEl.textContent = rd.population ? formatNumber(rd.population) : '-';
            if (capEl) capEl.textContent = rd.capital ? `مرکز: ${rd.capital}` : '';
            const containerRect = container.getBoundingClientRect();
            let x = clientX - containerRect.left + 16;
            let y = clientY - containerRect.top + 16;
            tooltip.classList.add('is-visible');
            tooltip.setAttribute('aria-hidden', 'false');
            const tipRect = tooltip.getBoundingClientRect();
            if (x + tipRect.width > containerRect.width) x = clientX - containerRect.left - tipRect.width - 16;
            if (y + tipRect.height > containerRect.height) y = clientY - containerRect.top - tipRect.height - 16;
            x = Math.max(8, Math.min(x, containerRect.width - tipRect.width - 8));
            y = Math.max(8, Math.min(y, containerRect.height - tipRect.height - 8));
            tooltip.style.left = x + 'px';
            tooltip.style.top = y + 'px';
        }
        function hideTooltip() {
            if (!tooltip) return;
            tooltip.classList.remove('is-visible');
            tooltip.setAttribute('aria-hidden', 'true');
        }

        // County loading
        function parseCountySVG(svgText) {
            const parser = new DOMParser();
            const doc = parser.parseFromString(svgText, 'image/svg+xml');
            const paths = [];
            doc.querySelectorAll('path').forEach((p, idx) => {
                const id = p.getAttribute('id') || `county-${idx}`;
                const slug = p.getAttribute('data-slug') || id.replace('county-','').replace('province-','') || `county-${idx}`;
                const d = p.getAttribute('d');
                if (!d) return;
                paths.push({ id, slug, d });
            });
            return paths;
        }
        function loadCounties(slug) {
            if (countyCache.has(slug)) {
                const cached = countyCache.get(slug);
                if (cached.loaded) return Promise.resolve(cached.paths);
                return cached.promise;
            }
            const possibleUrls = [
                countiesBaseUrl + slug + '.svg',
                '/wp-content/themes/iran-map/assets/svg/counties/' + slug + '.svg',
                '/counties/' + slug + '.svg'
            ];
            const tryFetch = (urls, index = 0) => {
                if (index >= urls.length) return Promise.reject(new Error('County SVG not found'));
                return fetch(urls[index]).then(res => {
                    if (!res.ok) throw new Error('Not ok');
                    return res.text();
                }).then(text => parseCountySVG(text)).catch(() => tryFetch(urls, index+1));
            };
            const promise = tryFetch(possibleUrls).then(paths => {
                countyCache.set(slug, { paths, loaded: true, promise: Promise.resolve(paths) });
                return paths;
            }).catch(err => {
                console.warn('Failed to load counties for', slug, err);
                countyCache.set(slug, { paths: [], loaded: true, promise: Promise.resolve([]) });
                return [];
            });
            countyCache.set(slug, { paths: [], loaded: false, promise });
            return promise;
        }
        function prefetchCounties(slug) {
            if (countyCache.has(slug) && countyCache.get(slug).loaded) return;
            loadCounties(slug);
        }
        function showLoading() { if (loadingEl) { loadingEl.classList.add('is-visible'); loadingEl.setAttribute('aria-hidden','false'); } }
        function hideLoading() { if (loadingEl) { loadingEl.classList.remove('is-visible'); loadingEl.setAttribute('aria-hidden','true'); } }
        function renderCounties(slug, paths) {
            countiesGroup.innerHTML = '';
            countiesGroup.setAttribute('aria-hidden','false');
            const fragment = document.createDocumentFragment();
            paths.forEach(p => {
                const rd = regionBySlug[p.slug] || {};
                const nameFa = rd.name_fa || p.slug;
                const a = document.createElementNS('http://www.w3.org/2000/svg','a');
                const href = `/${slug}/${p.slug}/`;
                a.setAttribute('href', href);
                a.setAttributeNS('http://www.w3.org/1999/xlink','href', href);
                a.setAttribute('class','iran-map-region-link');
                a.setAttribute('data-slug', p.slug);
                a.setAttribute('data-parent', slug);
                const pathEl = document.createElementNS('http://www.w3.org/2000/svg','path');
                pathEl.setAttribute('id', p.id);
                pathEl.setAttribute('data-slug', p.slug);
                pathEl.setAttribute('data-name-fa', nameFa);
                pathEl.setAttribute('class','county');
                pathEl.setAttribute('d', p.d);
                pathEl.setAttribute('vector-effect','non-scaling-stroke');
                pathEl.setAttribute('shape-rendering','geometricPrecision');
                pathEl.style.opacity = '0';
                pathEl.style.transform = 'translate3d(0, 8px, 0)';
                a.appendChild(pathEl);
                fragment.appendChild(a);
            });
            countiesGroup.appendChild(fragment);
            const countyEls = countiesGroup.querySelectorAll('.county');
            if (prefersReducedMotion) {
                countyEls.forEach(el => { el.style.opacity='1'; el.style.transform='translate3d(0,0,0)'; });
                countiesGroup.classList.add('is-visible');
            } else {
                countiesGroup.classList.add('is-visible');
                countyEls.forEach((el,i) => {
                    setTimeout(() => {
                        el.style.transition='transform 400ms ease-out, opacity 400ms ease-out';
                        el.style.opacity='1';
                        el.style.transform='translate3d(0,0,0)';
                    }, i*20);
                });
            }
            // Add click handlers for counties
            countiesGroup.querySelectorAll('.iran-map-region-link').forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    const countySlug = link.dataset.slug;
                    const parentSlug = link.dataset.parent || slug;
                    zoomToCounty(parentSlug, countySlug, { clientX: e.clientX, clientY: e.clientY });
                });
            });
        }
        function clearCountiesWithStagger(reverse=false) {
            const countyEls = countiesGroup.querySelectorAll('.county');
            if (countyEls.length===0) { countiesGroup.innerHTML=''; countiesGroup.classList.remove('is-visible'); return Promise.resolve(); }
            return new Promise(resolve => {
                if (prefersReducedMotion) { countiesGroup.innerHTML=''; countiesGroup.classList.remove('is-visible'); resolve(); return; }
                const els = Array.from(countyEls);
                if (reverse) els.reverse();
                els.forEach((el,i) => {
                    setTimeout(() => { el.style.opacity='0'; el.style.transform='translate3d(0, 8px, 0)'; }, i*20);
                });
                setTimeout(() => { countiesGroup.innerHTML=''; countiesGroup.classList.remove('is-visible'); resolve(); }, els.length*20+400);
            });
        }

        // Ripple
        function createRipple(clientX, clientY) {
            if (!rippleGroup) return;
            const pt = svg.createSVGPoint();
            pt.x = clientX; pt.y = clientY;
            let svgP;
            try { svgP = pt.matrixTransform(svg.getScreenCTM().inverse()); } catch(e) { return; }
            const circle = document.createElementNS('http://www.w3.org/2000/svg','circle');
            circle.setAttribute('cx', svgP.x);
            circle.setAttribute('cy', svgP.y);
            circle.setAttribute('r','0');
            circle.setAttribute('class','iran-map-ripple');
            rippleGroup.appendChild(circle);
            const maxR = Math.max(baseVB.w, baseVB.h)*0.3;
            let start=null;
            const duration = prefersReducedMotion?0:500;
            function animateRipple(timestamp) {
                if (!start) start=timestamp;
                const elapsed=timestamp-start;
                const progress=Math.min(elapsed/duration,1);
                const eased=1-Math.pow(1-progress,3);
                const r=maxR*eased;
                const opacity=1-progress;
                circle.setAttribute('r',r);
                circle.style.opacity=opacity;
                if (progress<1) requestAnimationFrame(animateRipple);
                else circle.remove();
            }
            if (prefersReducedMotion) circle.remove();
            else requestAnimationFrame(animateRipple);
        }

        // Panel
        function getPanelOffset() {
            // For mobile bottom sheet, how much height is covered
            if (window.innerWidth >= 768) return 0; // Desktop/tablet side panel, no vertical offset
            if (!panel.classList.contains('is-visible')) return 0;
            const snap = panel.dataset.snap || 'half';
            const vh = window.innerHeight;
            let sheetHeight = 0;
            if (snap === 'peek') sheetHeight = 120;
            else if (snap === 'half') sheetHeight = vh * 0.5;
            else if (snap === 'full') sheetHeight = vh * 0.9;
            return sheetHeight;
        }
        function adjustVBForPanel(vb) {
            const offset = getPanelOffset();
            if (offset === 0) return vb;
            // Shift viewBox up so region appears above sheet
            // visible map height = container height - offset
            // We want center to be at visibleHeight/2 from top, not containerHeight/2
            // So shift vb.y up by (offset / containerHeight * vb.h * 0.5)
            const containerRect = container.getBoundingClientRect();
            const containerH = containerRect.height || window.innerHeight;
            const shift = (offset / containerH) * vb.h * 0.4;
            return { x: vb.x, y: vb.y - shift, w: vb.w, h: vb.h };
        }
        function openPanel(regionData, options = {}) {
            const { focusReturnElement = null, countySlug = null } = options;
            if (!regionData) return;
            lastFocusedElement = focusReturnElement || document.activeElement;

            // Content
            const nameFa = regionData.name_fa || regionData.slug_en || '';
            const summary = `مرکز: ${regionData.capital || '-'} | آب و هوا: ${regionData.climate || '-'} | همسایگان: ${regionData.neighbors || '-'}`;
            const stats = [
                { label: 'مساحت', value: regionData.area_km2 ? `${formatNumber(regionData.area_km2)} km²` : '-' },
                { label: 'جمعیت', value: regionData.population ? formatNumber(regionData.population) : '-' },
                { label: 'مرکز', value: regionData.capital || '-' },
                { label: 'آب و هوا', value: regionData.climate || '-' },
            ];
            if (panelTitle) {
                panelTitle.textContent = nameFa;
                panelTitle.setAttribute('tabindex','-1');
            }
            if (panelSummary) panelSummary.textContent = summary;
            if (panelStats) {
                panelStats.innerHTML = '';
                stats.forEach(s => {
                    const div = document.createElement('div');
                    div.className = 'iran-map-panel-stat';
                    div.innerHTML = `<span class="label">${s.label}</span><span class="value">${s.value}</span>`;
                    panelStats.appendChild(div);
                });
                if (countySlug) {
                    const countyData = regionBySlug[countySlug] || countyBySlug[`${regionData.slug_en}/${countySlug}`];
                    if (countyData) {
                        const extra = [
                            { label: 'شهرستان', value: countyData.name_fa || countySlug },
                            { label: 'مساحت شهرستان', value: countyData.area_km2 ? `${formatNumber(countyData.area_km2)} km²` : '-' }
                        ];
                        extra.forEach(s => {
                            const div = document.createElement('div');
                            div.className = 'iran-map-panel-stat';
                            div.innerHTML = `<span class="label">${s.label}</span><span class="value">${s.value}</span>`;
                            panelStats.appendChild(div);
                        });
                    }
                }
            }
            if (panelLink) {
                let href = '/';
                if (regionData.type === 'province') href = `/${regionData.slug_en}/`;
                else if (regionData.type === 'county') href = `/${regionData.parent_slug}/${regionData.slug_en}/`;
                else if (countySlug) href = `/${regionData.slug_en}/${countySlug}/`;
                else href = `/${regionData.slug_en}/`;
                panelLink.setAttribute('href', href);
                panelLink.textContent = `مشاهده صفحه کامل ${nameFa}`;
            }
            if (panelImg) {
                // Placeholder - no real photo yet
                panelImg.style.display = 'none';
            }

            // Show panel
            panel.classList.add('is-visible');
            panel.setAttribute('aria-hidden','false');
            // Snap: desktop full, mobile half by default
            if (window.innerWidth < 768) {
                panel.dataset.snap = 'half';
                panelSnap = 'half';
            } else {
                panel.removeAttribute('data-snap');
            }

            // Focus management: move focus into panel
            setTimeout(() => {
                if (panelTitle) panelTitle.focus();
            }, 100);

            // Re-center map so region not hidden behind sheet
            if (focusedSlug) {
                const bbox = getRegionBBox(focusedSlug);
                if (bbox) {
                    const targetVB = computeTargetVBForRegion(bbox);
                    const adjusted = adjustVBForPanel(targetVB);
                    const fromTr = vbToTransform(currentVB);
                    const toTr = vbToTransform(adjusted);
                    svg.setAttribute('viewBox', vbToStr(baseVB));
                    applyTransform(fromTr);
                    animateTransform(fromTr, toTr, prefersReducedMotion?0:300, null, () => {
                        resetTransformToVB(adjusted);
                    });
                }
            }
        }
        function closePanel(options = {}) {
            const { returnFocus = true, updateHash = true } = options;
            panel.classList.remove('is-visible');
            panel.setAttribute('aria-hidden','true');
            panel.removeAttribute('data-snap');
            if (returnFocus && lastFocusedElement) {
                try { lastFocusedElement.focus(); } catch(e) {}
                lastFocusedElement = null;
            }
            if (updateHash) {
                updateHashState(null, null, true);
            }
        }

        // Hash handling
        function parseHash() {
            const hash = window.location.hash || '';
            // Expected #/isfahan/kashan or #/isfahan
            let clean = hash.replace(/^#\/?/, '').replace(/^\//, '');
            if (!clean) return null;
            const parts = clean.split('/').filter(Boolean).map(p => decodeURIComponent(p));
            if (parts.length === 0) return null;
            if (parts.length === 1) return { province: parts[0], county: null };
            return { province: parts[0], county: parts[1] };
        }
        function buildHash(province, county) {
            if (!province) return '';
            if (county) return `#/${encodeURIComponent(province)}/${encodeURIComponent(county)}`;
            return `#/${encodeURIComponent(province)}`;
        }
        function updateHashState(province, county, replace = false) {
            if (isUpdatingHash) return;
            isUpdatingHash = true;
            const newHash = buildHash(province, county);
            const url = newHash ? `${window.location.pathname}${newHash}` : window.location.pathname;
            try {
                if (replace) history.replaceState({ province, county }, '', url);
                else history.pushState({ province, county }, '', url);
            } catch(e) {
                // Fallback to location.hash
                if (replace) window.location.replace(url);
                else window.location.hash = newHash;
            }
            setTimeout(() => { isUpdatingHash = false; }, 100);
        }
        function restoreFromHash() {
            if (isUpdatingHash) return;
            const parsed = parseHash();
            if (!parsed) {
                if (focusedSlug) zoomOut({ updateHash: false, withAnimation: true });
                return;
            }
            const { province, county } = parsed;
            if (county) {
                zoomToCounty(province, county, { pushHistory: false, withRipple: false });
            } else {
                zoomToProvince(province, { pushHistory: false, withRipple: false });
            }
        }

        // Region BBox and target VB
        function getRegionBBox(slug) {
            const pathEl = svg.querySelector(`[data-slug="${slug}"]`);
            if (!pathEl) return null;
            try { return pathEl.getBBox(); } catch(e) { return null; }
        }
        function computeTargetVBForRegion(bbox) {
            if (!bbox) return { ...baseVB };
            const paddingFactor = 0.6;
            const targetW = bbox.width / paddingFactor;
            const targetH = bbox.height / paddingFactor;
            const scaleW = baseVB.w / targetW;
            const scaleH = baseVB.h / targetH;
            const scale = Math.min(scaleW, scaleH);
            const clampedScale = Math.max(1.5, Math.min(scale, 4));
            const vbW = baseVB.w / clampedScale;
            const vbH = baseVB.h / clampedScale;
            const centerX = bbox.x + bbox.width/2;
            const centerY = bbox.y + bbox.height/2;
            let vb = { x: centerX - vbW/2, y: centerY - vbH/2, w: vbW, h: vbH };
            vb = adjustVBForPanel(vb);
            return vb;
        }

        // Zoom to province
        function zoomToProvince(slug, options = {}) {
            const { clientX, clientY, withRipple = true, pushHistory = true, focusElement = null } = options;
            if (!slug) return;
            if (focusedSlug === slug && focusedCountySlug === null && !isAnimating) {
                // Already focused, just open panel
                const rd = regionBySlug[slug];
                if (rd) openPanel(rd, { focusReturnElement: focusElement });
                return;
            }
            const bbox = getRegionBBox(slug);
            if (!bbox) {
                // If bbox not found, maybe need to load counties? For province, bbox should exist
                // Try to prefetch and then zoom
                prefetchCounties(slug);
                return;
            }
            let targetVB = computeTargetVBForRegion(bbox);
            const fromTransform = vbToTransform(currentVB);
            const toTransform = vbToTransform(targetVB);

            if (withRipple && clientX && clientY) createRipple(clientX, clientY);

            const cacheEntry = countyCache.get(slug);
            const needLoad = !cacheEntry || !cacheEntry.loaded;
            let loadingTimeout = null;
            if (needLoad) loadingTimeout = setTimeout(() => showLoading(), 200);
            const loadPromise = loadCounties(slug);

            container.classList.add('is-focused');
            const allProvinceLinks = provincesGroup.querySelectorAll('.iran-map-region-link');
            allProvinceLinks.forEach(link => {
                if (link.dataset.slug === slug) {
                    link.classList.add('is-focused');
                    const p = link.querySelector('.province');
                    if (p) p.classList.add('is-focused');
                } else link.classList.remove('is-focused');
            });

            const doZoom = () => {
                if (loadingTimeout) clearTimeout(loadingTimeout);
                hideLoading();
                svg.setAttribute('viewBox', vbToStr(baseVB));
                applyTransform(fromTransform);
                animateTransform(fromTransform, toTransform, prefersReducedMotion?0:700, null, () => {
                    resetTransformToVB(targetVB);
                    focusedSlug = slug;
                    focusedCountySlug = null;
                    currentVB = { ...targetVB };
                    currentZoom = baseVB.w / currentVB.w;
                    loadPromise.then(paths => { if (paths && paths.length>0) renderCounties(slug, paths); });
                    if (pushHistory) updateHashState(slug, null, false);
                    const rd = regionBySlug[slug];
                    if (rd) openPanel(rd, { focusReturnElement: focusElement });
                    container.setAttribute('aria-label', `نمایش شهرستان‌های ${rd?.name_fa || slug}`);
                });
            };

            if (focusedSlug && focusedSlug !== slug) {
                clearCountiesWithStagger(true).then(doZoom);
            } else {
                if (needLoad) loadPromise.then(() => { if (!isAnimating) renderCounties(slug, countyCache.get(slug).paths); });
                doZoom();
            }
        }

        // Zoom to county
        function zoomToCounty(provinceSlug, countySlug, options = {}) {
            const { clientX, clientY, withRipple = true, pushHistory = true, focusElement = null } = options;
            // First ensure province is loaded and focused, then zoom to county
            const countyKey = `${provinceSlug}/${countySlug}`;
            const countyData = regionBySlug[countySlug] || countyBySlug[countyKey] || countyBySlug[countySlug];
            // If province not focused, first zoom to province, then to county
            if (focusedSlug !== provinceSlug) {
                // Zoom to province first, then after, zoom to county
                zoomToProvince(provinceSlug, { clientX, clientY, withRipple, pushHistory: false, focusElement });
                // After province zoom, need to zoom to county bbox
                setTimeout(() => {
                    const countyPath = countiesGroup.querySelector(`[data-slug="${countySlug}"]`) || svg.querySelector(`[data-slug="${countySlug}"]`);
                    let bbox = null;
                    if (countyPath) {
                        try { bbox = countyPath.getBBox(); } catch(e) {}
                    }
                    if (!bbox) {
                        // Try to find in cache and compute from region data? Fallback to province bbox
                        bbox = getRegionBBox(provinceSlug);
                    }
                    if (bbox) {
                        let targetVB = computeTargetVBForRegion(bbox);
                        const fromTr = vbToTransform(currentVB);
                        const toTr = vbToTransform(targetVB);
                        svg.setAttribute('viewBox', vbToStr(baseVB));
                        applyTransform(fromTr);
                        animateTransform(fromTr, toTr, prefersReducedMotion?0:600, null, () => {
                            resetTransformToVB(targetVB);
                            focusedSlug = provinceSlug;
                            focusedCountySlug = countySlug;
                            currentVB = { ...targetVB };
                            if (pushHistory) updateHashState(provinceSlug, countySlug, false);
                            const provinceData = regionBySlug[provinceSlug];
                            if (provinceData) openPanel(provinceData, { focusReturnElement: focusElement, countySlug });
                        });
                    }
                }, 800);
                return;
            }

            // Province already focused, zoom to county
            const countyPath = countiesGroup.querySelector(`[data-slug="${countySlug}"]`) || svg.querySelector(`[data-slug="${countySlug}"]`);
            let bbox = null;
            if (countyPath) {
                try { bbox = countyPath.getBBox(); } catch(e) {}
            }
            if (!bbox) bbox = getRegionBBox(provinceSlug);
            if (!bbox) return;

            let targetVB = computeTargetVBForRegion(bbox);
            const fromTr = vbToTransform(currentVB);
            const toTr = vbToTransform(targetVB);

            if (withRipple && clientX && clientY) createRipple(clientX, clientY);

            svg.setAttribute('viewBox', vbToStr(baseVB));
            applyTransform(fromTr);
            animateTransform(fromTr, toTr, prefersReducedMotion?0:600, null, () => {
                resetTransformToVB(targetVB);
                focusedCountySlug = countySlug;
                currentVB = { ...targetVB };
                if (pushHistory) updateHashState(provinceSlug, countySlug, false);
                const provinceData = regionBySlug[provinceSlug];
                if (provinceData) openPanel(provinceData, { focusReturnElement: focusElement, countySlug });
            });
        }

        function zoomOut(options = {}) {
            const { updateHash = true, withAnimation = true, returnFocus = true } = options;
            if (!focusedSlug && currentVB.w === baseVB.w && currentVB.h === baseVB.h) {
                if (panel.classList.contains('is-visible')) closePanel({ returnFocus, updateHash });
                return;
            }
            const fromTransform = vbToTransform(currentVB);
            const toTransform = vbToTransform(baseVB);
            clearCountiesWithStagger(true).then(() => {
                container.classList.remove('is-focused');
                provincesGroup.querySelectorAll('.iran-map-region-link').forEach(link => {
                    link.classList.remove('is-focused');
                    const p = link.querySelector('.province');
                    if (p) p.classList.remove('is-focused');
                });
                if (!withAnimation || prefersReducedMotion) {
                    resetTransformToVB(baseVB);
                    focusedSlug = null;
                    focusedCountySlug = null;
                    hideTooltip();
                    closePanel({ returnFocus, updateHash });
                    return;
                }
                svg.setAttribute('viewBox', vbToStr(baseVB));
                applyTransform(fromTransform);
                animateTransform(fromTransform, toTransform, 700, null, () => {
                    resetTransformToVB(baseVB);
                    focusedSlug = null;
                    focusedCountySlug = null;
                    hideTooltip();
                    closePanel({ returnFocus, updateHash });
                    container.setAttribute('aria-label','نقشه تعاملی ایران');
                });
            });
        }

        // Panel events
        if (panelClose) {
            panelClose.addEventListener('click', () => zoomOut({ returnFocus: true, updateHash: true }));
        }
        // Bottom sheet drag
        let dragStartY = 0;
        let dragCurrentY = 0;
        let isDraggingSheet = false;
        let startSnap = 'half';

        function onSheetDragStart(e) {
            if (window.innerWidth >= 768) return;
            isDraggingSheet = true;
            startSnap = panel.dataset.snap || 'half';
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            dragStartY = clientY;
            dragCurrentY = clientY;
            panel.style.transition = 'none';
            if (e.type === 'mousedown') e.preventDefault();
        }
        function onSheetDragMove(e) {
            if (!isDraggingSheet) return;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            dragCurrentY = clientY;
            const deltaY = clientY - dragStartY;
            // Apply transform based on delta
            // For simplicity, we adjust translateY
            const currentTranslate = panel.getBoundingClientRect().top;
            // We use data-snap to determine base position, then add delta
            // Instead of precise, we just move panel with delta
            if (deltaY > 0) {
                panel.style.transform = `translate3d(0, ${deltaY}px, 0)`;
            } else {
                // Dragging up - allow but with resistance
                const resistance = Math.max(deltaY * 0.3, -100);
                panel.style.transform = `translate3d(0, ${resistance}px, 0)`;
            }
            if (e.cancelable) e.preventDefault();
        }
        function onSheetDragEnd() {
            if (!isDraggingSheet) return;
            isDraggingSheet = false;
            panel.style.transition = '';
            panel.style.transform = '';
            const deltaY = dragCurrentY - dragStartY;
            // Determine snap based on delta and velocity
            if (deltaY > 100) {
                // Dragged down significantly
                if (startSnap === 'full') {
                    panel.dataset.snap = 'half';
                    panelSnap = 'half';
                } else if (startSnap === 'half') {
                    panel.dataset.snap = 'peek';
                    panelSnap = 'peek';
                } else {
                    // peek -> close?
                    if (deltaY > 150) zoomOut();
                    else panel.dataset.snap = 'peek';
                }
            } else if (deltaY < -100) {
                // Dragged up
                if (startSnap === 'peek') {
                    panel.dataset.snap = 'half';
                    panelSnap = 'half';
                } else if (startSnap === 'half') {
                    panel.dataset.snap = 'full';
                    panelSnap = 'full';
                }
            }
            // Re-center map for new snap
            if (focusedSlug) {
                const bbox = getRegionBBox(focusedSlug);
                if (bbox) {
                    const targetVB = computeTargetVBForRegion(bbox);
                    const adjusted = adjustVBForPanel(targetVB);
                    // If adjusted differs, animate
                    if (Math.abs(adjusted.y - currentVB.y) > 1) {
                        const fromTr = vbToTransform(currentVB);
                        const toTr = vbToTransform(adjusted);
                        svg.setAttribute('viewBox', vbToStr(baseVB));
                        applyTransform(fromTr);
                        animateTransform(fromTr, toTr, 300, null, () => {
                            resetTransformToVB(adjusted);
                        });
                    }
                }
            }
        }

        if (panelHandle) {
            panelHandle.addEventListener('mousedown', onSheetDragStart);
            panelHandle.addEventListener('touchstart', onSheetDragStart, { passive: true });
        }
        panel.addEventListener('mousedown', (e) => {
            if (e.target === panelHandle || panelHandle.contains(e.target)) onSheetDragStart(e);
        });
        panel.addEventListener('touchstart', (e) => {
            if (e.target === panelHandle || panelHandle.contains(e.target)) onSheetDragStart(e);
        }, { passive: true });
        window.addEventListener('mousemove', onSheetDragMove);
        window.addEventListener('touchmove', onSheetDragMove, { passive: false });
        window.addEventListener('mouseup', onSheetDragEnd);
        window.addEventListener('touchend', onSheetDragEnd);

        // Search
        let searchActiveIndex = -1;
        let searchResults = [];
        let searchDebounce = null;

        function renderSearchResults(results, query) {
            if (!searchList) return;
            searchList.innerHTML = '';
            searchActiveIndex = -1;
            if (!query) {
                searchList.classList.remove('is-visible');
                if (searchInput) searchInput.setAttribute('aria-expanded','false');
                if (searchStatus) searchStatus.textContent = '';
                return;
            }
            if (results.length === 0) {
                const empty = document.createElement('div');
                empty.className = 'iran-map-search-empty';
                empty.textContent = 'نتیجه‌ای یافت نشد';
                searchList.appendChild(empty);
                searchList.classList.add('is-visible');
                if (searchInput) searchInput.setAttribute('aria-expanded','true');
                if (searchStatus) searchStatus.textContent = 'نتیجه‌ای یافت نشد';
                return;
            }
            results.slice(0, 20).forEach((item, idx) => {
                const div = document.createElement('div');
                div.className = 'iran-map-search-item';
                div.setAttribute('role','option');
                div.setAttribute('id', `iran-map-search-item-${idx}`);
                div.setAttribute('data-slug', item.slug);
                div.setAttribute('data-parent', item.parent || '');
                div.setAttribute('data-type', item.type);
                const typeLabel = item.type === 'province' ? 'استان' : 'شهرستان';
                const subtitle = item.type === 'county' ? (item.provinceName || item.parent || '') : '';
                div.innerHTML = `
                    <span class="iran-map-search-item-type ${item.type}">${typeLabel}</span>
                    <span class="iran-map-search-item-content">
                        <span class="iran-map-search-item-title">${item.original.name_fa}</span>
                        ${subtitle ? `<span class="iran-map-search-item-subtitle">${subtitle}</span>` : ''}
                    </span>
                `;
                div.addEventListener('click', () => selectSearchResult(item));
                div.addEventListener('mouseenter', () => setActiveSearchItem(idx));
                searchList.appendChild(div);
            });
            searchList.classList.add('is-visible');
            if (searchInput) searchInput.setAttribute('aria-expanded','true');
            if (searchStatus) searchStatus.textContent = `${results.length} نتیجه یافت شد`;
        }

        function setActiveSearchItem(index) {
            const items = searchList.querySelectorAll('.iran-map-search-item');
            items.forEach((el,i) => {
                if (i === index) {
                    el.classList.add('is-active');
                    el.setAttribute('aria-selected','true');
                    if (searchInput) searchInput.setAttribute('aria-activedescendant', el.id);
                } else {
                    el.classList.remove('is-active');
                    el.setAttribute('aria-selected','false');
                }
            });
            searchActiveIndex = index;
        }

        function selectSearchResult(item) {
            if (!item) return;
            // Clear search
            if (searchInput) {
                searchInput.value = item.original.name_fa;
                searchInput.setAttribute('aria-expanded','false');
            }
            if (searchList) searchList.classList.remove('is-visible');
            if (searchClear) searchClear.classList.add('is-visible');
            // Zoom to result
            if (item.type === 'province') {
                zoomToProvince(item.slug, { focusElement: searchInput });
            } else {
                // County: need parent
                const parent = item.parent || item.original.parent_slug;
                if (parent) zoomToCounty(parent, item.slug, { focusElement: searchInput });
                else zoomToProvince(item.slug, { focusElement: searchInput });
            }
        }

        function performSearch(query) {
            const normQuery = normalizePersian(query);
            if (!normQuery) {
                searchResults = [];
                renderSearchResults([], '');
                return;
            }
            // Prefix + substring, provinces first
            const prefixMatches = [];
            const substringMatches = [];
            searchIndex.forEach(item => {
                const nameNorm = item.normalized;
                const enNorm = item.normalizedEn;
                if (nameNorm.startsWith(normQuery) || enNorm.startsWith(normQuery)) {
                    prefixMatches.push(item);
                } else if (nameNorm.includes(normQuery) || enNorm.includes(normQuery)) {
                    substringMatches.push(item);
                }
            });
            // Sort: provinces first, then by name length, then alphabetical
            const sortFn = (a,b) => {
                if (a.type !== b.type) return a.type === 'province' ? -1 : 1;
                if (a.normalized.length !== b.normalized.length) return a.normalized.length - b.normalized.length;
                return a.original.name_fa.localeCompare(b.original.name_fa, 'fa');
            };
            prefixMatches.sort(sortFn);
            substringMatches.sort(sortFn);
            searchResults = [...prefixMatches, ...substringMatches];
            renderSearchResults(searchResults, query);
        }

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const val = e.target.value;
                if (searchClear) {
                    if (val) searchClear.classList.add('is-visible');
                    else searchClear.classList.remove('is-visible');
                }
                if (searchDebounce) clearTimeout(searchDebounce);
                searchDebounce = setTimeout(() => performSearch(val), 50);
            });
            searchInput.addEventListener('keydown', (e) => {
                const items = searchList ? searchList.querySelectorAll('.iran-map-search-item') : [];
                switch(e.key) {
                    case 'ArrowDown':
                        e.preventDefault();
                        if (searchResults.length === 0) return;
                        setActiveSearchItem((searchActiveIndex + 1) % Math.min(searchResults.length, 20));
                        break;
                    case 'ArrowUp':
                        e.preventDefault();
                        if (searchResults.length === 0) return;
                        setActiveSearchItem((searchActiveIndex - 1 + Math.min(searchResults.length, 20)) % Math.min(searchResults.length, 20));
                        break;
                    case 'Enter':
                        e.preventDefault();
                        if (searchActiveIndex >= 0 && searchResults[searchActiveIndex]) {
                            selectSearchResult(searchResults[searchActiveIndex]);
                        } else if (searchResults.length > 0) {
                            selectSearchResult(searchResults[0]);
                        }
                        break;
                    case 'Escape':
                        e.preventDefault();
                        if (searchList) searchList.classList.remove('is-visible');
                        searchInput.setAttribute('aria-expanded','false');
                        searchActiveIndex = -1;
                        if (searchStatus) searchStatus.textContent = '';
                        break;
                }
            });
            searchInput.addEventListener('focus', () => {
                if (searchInput.value) performSearch(searchInput.value);
            });
            // Close search when clicking outside
            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchList.contains(e.target)) {
                    searchList.classList.remove('is-visible');
                    searchInput.setAttribute('aria-expanded','false');
                }
            });
        }
        if (searchClear) {
            searchClear.addEventListener('click', () => {
                if (searchInput) {
                    searchInput.value = '';
                    searchInput.focus();
                    searchClear.classList.remove('is-visible');
                    if (searchList) searchList.classList.remove('is-visible');
                    if (searchInput) searchInput.setAttribute('aria-expanded','false');
                    if (searchStatus) searchStatus.textContent = '';
                }
            });
        }

        // Hover handling (from step 4)
        function handleHover(slug, clientX, clientY) {
            if (focusedSlug) return;
            if (hoveredSlug === slug) {
                if (clientX && clientY) showTooltip(slug, clientX, clientY);
                return;
            }
            if (hoveredSlug) {
                const prev = svg.querySelector(`[data-slug="${hoveredSlug}"]`);
                if (prev) prev.classList.remove('is-hovered');
                const prevLink = svg.querySelector(`.iran-map-region-link[data-slug="${hoveredSlug}"]`);
                if (prevLink) prevLink.classList.remove('is-hovered');
            }
            hoveredSlug = slug;
            const pathEl = svg.querySelector(`[data-slug="${slug}"]`);
            if (pathEl) pathEl.classList.add('is-hovered');
            const linkEl = svg.querySelector(`.iran-map-region-link[data-slug="${slug}"]`);
            if (linkEl) linkEl.classList.add('is-hovered');
            if (clientX && clientY) showTooltip(slug, clientX, clientY);
            prefetchCounties(slug);
        }
        function handleLeave() {
            if (hoveredSlug) {
                const prev = svg.querySelector(`[data-slug="${hoveredSlug}"]`);
                if (prev) prev.classList.remove('is-hovered');
                const prevLink = svg.querySelector(`.iran-map-region-link[data-slug="${hoveredSlug}"]`);
                if (prevLink) prevLink.classList.remove('is-hovered');
            }
            hoveredSlug = null;
            hideTooltip();
        }

        const provinceLinks = provincesGroup.querySelectorAll('.iran-map-region-link');
        provinceLinks.forEach(link => {
            const slug = link.dataset.slug;
            link.addEventListener('mouseenter', (e) => { if (isTouchDevice) return; handleHover(slug, e.clientX, e.clientY); });
            link.addEventListener('mousemove', (e) => { if (isTouchDevice) return; if (hoveredSlug === slug) showTooltip(slug, e.clientX, e.clientY); });
            link.addEventListener('mouseleave', () => { if (isTouchDevice) return; handleLeave(); });
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const now = Date.now();
                if (isTouchDevice) {
                    if (lastTap.slug === slug && (now - lastTap.time) < 500) {
                        zoomToProvince(slug, { clientX: e.clientX, clientY: e.clientY, focusElement: link });
                        lastTap = { slug: null, time: 0 };
                    } else {
                        handleHover(slug, e.clientX, e.clientY);
                        lastTap = { slug, time: now };
                        prefetchCounties(slug);
                    }
                } else {
                    zoomToProvince(slug, { clientX: e.clientX, clientY: e.clientY, focusElement: link });
                }
            });
            link.addEventListener('touchstart', (e) => {
                if (e.touches.length === 1) {
                    const touch = e.touches[0];
                    handleHover(slug, touch.clientX, touch.clientY);
                }
            }, { passive: true });
        });

        if (bgRect) {
            bgRect.addEventListener('click', (e) => { if (focusedSlug) { e.preventDefault(); zoomOut(); } });
        }
        container.addEventListener('click', (e) => {
            if (e.target === container || e.target === svg || e.target === bgRect || e.target.id === 'map-group') {
                if (focusedSlug) zoomOut();
            }
        });

        // Double-tap zoom
        let lastTapTime = 0;
        let lastTapPos = null;
        container.addEventListener('touchend', (e) => {
            const now = Date.now();
            if (now - lastTapTime < 300 && lastTapPos) {
                e.preventDefault();
                const touch = e.changedTouches[0];
                const x = touch.clientX, y = touch.clientY;
                const pt = svg.createSVGPoint();
                pt.x = x; pt.y = y;
                let svgP;
                try { svgP = pt.matrixTransform(svg.getScreenCTM().inverse()); } catch(err) { return; }
                const factor = 2;
                const newW = currentVB.w / factor;
                const newH = currentVB.h / factor;
                const targetVB = { x: svgP.x - newW/2, y: svgP.y - newH/2, w: newW, h: newH };
                const fromTr = vbToTransform(currentVB);
                const toTr = vbToTransform(targetVB);
                svg.setAttribute('viewBox', vbToStr(baseVB));
                applyTransform(fromTr);
                animateTransform(fromTr, toTr, prefersReducedMotion?0:600, null, () => { resetTransformToVB(targetVB); });
                lastTapTime = 0;
                lastTapPos = null;
            } else {
                lastTapTime = now;
                lastTapPos = e.changedTouches[0] ? { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY } : null;
            }
        });

        // Keyboard
        container.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            const step = currentVB.w * 0.1;
            let handled = false;
            switch(e.key) {
                case 'ArrowUp': e.preventDefault(); resetTransformToVB({ x: currentVB.x, y: currentVB.y - step, w: currentVB.w, h: currentVB.h }); handled=true; break;
                case 'ArrowDown': e.preventDefault(); resetTransformToVB({ x: currentVB.x, y: currentVB.y + step, w: currentVB.w, h: currentVB.h }); handled=true; break;
                case 'ArrowLeft': e.preventDefault(); resetTransformToVB({ x: currentVB.x - step, y: currentVB.y, w: currentVB.w, h: currentVB.h }); handled=true; break;
                case 'ArrowRight': e.preventDefault(); resetTransformToVB({ x: currentVB.x + step, y: currentVB.y, w: currentVB.w, h: currentVB.h }); handled=true; break;
                case 'Enter':
                    e.preventDefault();
                    if (hoveredSlug) zoomToProvince(hoveredSlug, { focusElement: document.activeElement });
                    else if (focusedSlug) zoomOut();
                    handled=true; break;
                case 'Escape':
                    e.preventDefault();
                    if (searchList && searchList.classList.contains('is-visible')) {
                        searchList.classList.remove('is-visible');
                        if (searchInput) { searchInput.setAttribute('aria-expanded','false'); searchInput.focus(); }
                    } else if (focusedSlug) zoomOut();
                    else hideTooltip();
                    handled=true; break;
                case '+': case '=': e.preventDefault(); { const f=1.5; const nw=currentVB.w/f, nh=currentVB.h/f, cx=currentVB.x+currentVB.w/2, cy=currentVB.y+currentVB.h/2; resetTransformToVB({ x: cx-nw/2, y: cy-nh/2, w: nw, h: nh }); } handled=true; break;
                case '-': case '_': e.preventDefault(); { const f=1.5; const nw=currentVB.w*f, nh=currentVB.h*f, cx=currentVB.x+currentVB.w/2, cy=currentVB.y+currentVB.h/2; resetTransformToVB({ x: cx-nw/2, y: cy-nh/2, w: nw, h: nh }); } handled=true; break;
                case '0': e.preventDefault(); if (focusedSlug) zoomOut(); else resetTransformToVB(baseVB); handled=true; break;
            }
        });

        // Controls
        const btnIn = document.getElementById('iran-map-zoom-in');
        const btnOut = document.getElementById('iran-map-zoom-out');
        const btnReset = document.getElementById('iran-map-reset');
        if (btnIn) btnIn.addEventListener('click', (e) => {
            e.preventDefault();
            const f=1.5; const nw=currentVB.w/f, nh=currentVB.h/f, cx=currentVB.x+currentVB.w/2, cy=currentVB.y+currentVB.h/2;
            const targetVB={ x: cx-nw/2, y: cy-nh/2, w: nw, h: nh };
            const fromTr=vbToTransform(currentVB); const toTr=vbToTransform(targetVB);
            svg.setAttribute('viewBox', vbToStr(baseVB)); applyTransform(fromTr);
            animateTransform(fromTr, toTr, prefersReducedMotion?0:400, null, () => resetTransformToVB(targetVB));
        });
        if (btnOut) btnOut.addEventListener('click', (e) => {
            e.preventDefault();
            if (focusedSlug) zoomOut();
            else {
                const f=1.5; const nw=currentVB.w*f, nh=currentVB.h*f, cx=currentVB.x+currentVB.w/2, cy=currentVB.y+currentVB.h/2;
                const targetVB={ x: cx-nw/2, y: cy-nh/2, w: nw, h: nh };
                const fromTr=vbToTransform(currentVB); const toTr=vbToTransform(targetVB);
                svg.setAttribute('viewBox', vbToStr(baseVB)); applyTransform(fromTr);
                animateTransform(fromTr, toTr, prefersReducedMotion?0:400, null, () => resetTransformToVB(targetVB));
            }
        });
        if (btnReset) btnReset.addEventListener('click', (e) => {
            e.preventDefault();
            if (focusedSlug) zoomOut();
            else {
                const fromTr=vbToTransform(currentVB); const toTr=vbToTransform(baseVB);
                svg.setAttribute('viewBox', vbToStr(baseVB)); applyTransform(fromTr);
                animateTransform(fromTr, toTr, prefersReducedMotion?0:500, null, () => resetTransformToVB(baseVB));
            }
        });

        // Wheel, drag, pinch
        let isDragging=false, dragStart={x:0,y:0}, vbStart={...currentVB};
        svg.addEventListener('wheel', (e) => {
            e.preventDefault();
            if (isAnimating) cancelAnimation();
            const rect=svg.getBoundingClientRect();
            const xPct=(e.clientX-rect.left)/rect.width;
            const yPct=(e.clientY-rect.top)/rect.height;
            const svgX=currentVB.x+xPct*currentVB.w;
            const svgY=currentVB.y+yPct*currentVB.h;
            const factor=e.deltaY>0?1.2:1/1.2;
            const newW=currentVB.w*factor, newH=currentVB.h*factor;
            const targetVB={ x: svgX-xPct*newW, y: svgY-yPct*newH, w: newW, h: newH };
            if (prefersReducedMotion) resetTransformToVB(targetVB);
            else {
                const fromTr=vbToTransform(currentVB); const toTr=vbToTransform(targetVB);
                svg.setAttribute('viewBox', vbToStr(baseVB)); applyTransform(fromTr);
                animateTransform(fromTr, toTr, 250, null, () => resetTransformToVB(targetVB));
            }
        }, { passive:false });
        svg.addEventListener('mousedown', (e) => {
            if (e.button!==0) return;
            if (e.target.closest('.iran-map-region-link')) return;
            isDragging=true; dragStart.x=e.clientX; dragStart.y=e.clientY; vbStart={...currentVB};
            svg.style.cursor='grabbing'; e.preventDefault();
        });
        window.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const dx=e.clientX-dragStart.x, dy=e.clientY-dragStart.y;
            const rect=svg.getBoundingClientRect();
            const sx=currentVB.w/rect.width, sy=currentVB.h/rect.height;
            resetTransformToVB({ x: vbStart.x-dx*sx, y: vbStart.y-dy*sy, w: currentVB.w, h: currentVB.h });
        });
        window.addEventListener('mouseup', () => { if (isDragging) { isDragging=false; svg.style.cursor='grab'; } });
        let lastDist=0;
        svg.addEventListener('touchstart', (e) => {
            if (e.touches.length===1) {
                if (e.target.closest('.iran-map-region-link')) return;
                isDragging=true; dragStart.x=e.touches[0].clientX; dragStart.y=e.touches[0].clientY; vbStart={...currentVB};
            } else if (e.touches.length===2) {
                isDragging=false;
                const dx=e.touches[0].clientX-e.touches[1].clientX, dy=e.touches[0].clientY-e.touches[1].clientY;
                lastDist=Math.hypot(dx,dy);
            }
        }, { passive:true });
        svg.addEventListener('touchmove', (e) => {
            if (e.touches.length===1 && isDragging) {
                const dx=e.touches[0].clientX-dragStart.x, dy=e.touches[0].clientY-dragStart.y;
                const rect=svg.getBoundingClientRect();
                const sx=currentVB.w/rect.width, sy=currentVB.h/rect.height;
                resetTransformToVB({ x: vbStart.x-dx*sx, y: vbStart.y-dy*sy, w: currentVB.w, h: currentVB.h });
                e.preventDefault();
            } else if (e.touches.length===2) {
                const dx=e.touches[0].clientX-e.touches[1].clientX, dy=e.touches[0].clientY-e.touches[1].clientY;
                const dist=Math.hypot(dx,dy);
                const cx=(e.touches[0].clientX+e.touches[1].clientX)/2, cy=(e.touches[0].clientY+e.touches[1].clientY)/2;
                if (lastDist>0) {
                    const factor=lastDist/dist;
                    const rect=svg.getBoundingClientRect();
                    const xPct=(cx-rect.left)/rect.width, yPct=(cy-rect.top)/rect.height;
                    const svgX=currentVB.x+xPct*currentVB.w, svgY=currentVB.y+yPct*currentVB.h;
                    const newW=currentVB.w*factor, newH=currentVB.h*factor;
                    resetTransformToVB({ x: svgX-xPct*newW, y: svgY-yPct*newH, w: newW, h: newH });
                }
                lastDist=dist;
                e.preventDefault();
            }
        }, { passive:false });
        svg.addEventListener('touchend', (e) => {
            if (e.touches.length===0) { isDragging=false; lastDist=0; }
            else if (e.touches.length===1) { isDragging=true; dragStart.x=e.touches[0].clientX; dragStart.y=e.touches[0].clientY; vbStart={...currentVB}; lastDist=0; }
        });

        // Hash handling
        window.addEventListener('hashchange', () => {
            if (isUpdatingHash) return;
            restoreFromHash();
        });
        window.addEventListener('popstate', (e) => {
            if (isUpdatingHash) return;
            const state = e.state;
            if (state && (state.province || state.county)) {
                const province = state.province;
                const county = state.county;
                if (county) zoomToCounty(province, county, { pushHistory: false, withRipple: false });
                else if (province) zoomToProvince(province, { pushHistory: false, withRipple: false });
                else zoomOut({ updateHash: false });
            } else {
                restoreFromHash();
            }
        });

        // Initial restore from hash or ?province param
        function initialRestore() {
            const hashParsed = parseHash();
            if (hashParsed) {
                const { province, county } = hashParsed;
                setTimeout(() => {
                    if (county) zoomToCounty(province, county, { pushHistory: false, withRipple: false });
                    else zoomToProvince(province, { pushHistory: false, withRipple: false });
                }, 100);
                return;
            }
            // Fallback to ?province= query param (from step 3)
            const urlParams = new URLSearchParams(window.location.search);
            const provinceParam = urlParams.get('province');
            if (provinceParam) {
                setTimeout(() => zoomToProvince(provinceParam, { pushHistory: false, withRipple: false }), 100);
            }
        }

        // Performance observer
        if ('PerformanceObserver' in window) {
            try {
                const observer = new PerformanceObserver((list) => {
                    list.getEntries().forEach(entry => {
                        if (entry.duration > 50) console.warn('Long task:', entry.duration, 'ms');
                    });
                });
                observer.observe({ entryTypes: ['longtask'] });
            } catch(e) {}
        }

        svg.style.cursor='grab';
        resetTransformToVB(currentVB);
        window.addEventListener('resize', () => { updateLabels(); });
        initialRestore();

        window.IranMap = {
            zoomToProvince,
            zoomToCounty,
            zoomOut,
            loadCounties,
            getCurrentVB: () => currentVB,
            getFocused: () => ({ province: focusedSlug, county: focusedCountySlug }),
            getCache: () => countyCache,
            normalizePersian,
            search: performSearch,
            openPanel,
            closePanel
        };
    }

    if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', initIranMap);
    else initIranMap();
})();
