<?php
/**
 * Front page - Step 5: Panel, URL state and search
 * - Desktop: map 60% + side panel 40%, tablet stacked, mobile draggable bottom sheet 3 snap points
 * - Panel: name, summary, key stats, view full page button, map re-centers so region not hidden
 * - History API pushState/popstate with hash /#/isfahan/kashan (keeps caching), back/forward/refresh/cold deep link restore
 * - Instant autocomplete 479 names: Persian normalization ي→ی, ك→ک, ZWNJ, Arabic/Persian digits, prefix+substring, provinces first, counties show province
 * - Accessible combobox keyboard up/down/Enter/Esc, selecting runs zoom animation
 * - Focus management: focus into panel on open, returns to region on close
 */
get_header();

$test_province_slug = isset($_GET['province']) ? sanitize_title($_GET['province']) : '';
$map_type = 'provinces';
$svg_file_path = '';
$regions_data = [];
$provinces_posts_map = [];

$regions_json_paths = [
    get_template_directory() . '/assets/svg/regions.json',
    get_template_directory() . '/../../regions.json',
    ABSPATH . '../regions.json',
    get_template_directory() . '/../../sample/regions.json',
    dirname(get_template_directory(), 3) . '/regions.json',
    '/home/user/MAP/regions.json',
    __DIR__ . '/../../regions.json',
    __DIR__ . '/../../../regions.json',
];
foreach ($regions_json_paths as $p) {
    if (file_exists($p)) {
        $content = file_get_contents($p);
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            $regions_data = $decoded;
            break;
        }
    }
}

if (post_type_exists('region')) {
    $all_regions = get_posts([
        'post_type'   => 'region',
        'numberposts' => -1,
        'post_status' => 'publish',
    ]);
    foreach ($all_regions as $r) {
        $provinces_posts_map[$r->post_name] = $r;
    }
}

if ($test_province_slug) {
    $county_svg_paths = [
        get_template_directory() . '/assets/svg/counties/' . $test_province_slug . '.svg',
        dirname(get_template_directory(), 3) . '/counties/' . $test_province_slug . '.svg',
        '/home/user/MAP/counties/' . $test_province_slug . '.svg',
        '/home/user/MAP/wp-content/themes/iran-map/assets/svg/counties/' . $test_province_slug . '.svg',
    ];
    foreach ($county_svg_paths as $csp) {
        if (file_exists($csp)) {
            $svg_file_path = $csp;
            $map_type = 'counties';
            break;
        }
    }
    if (empty($svg_file_path)) $test_province_slug = '';
}

if (empty($svg_file_path)) {
    $province_svg_paths = [
        get_template_directory() . '/assets/svg/iran-provinces.svg',
        dirname(get_template_directory(), 3) . '/iran-provinces.svg',
        '/home/user/MAP/iran-provinces.svg',
        '/home/user/MAP/wp-content/themes/iran-map/assets/svg/iran-provinces.svg',
    ];
    foreach ($province_svg_paths as $psp) {
        if (file_exists($psp)) {
            $svg_file_path = $psp;
            $map_type = 'provinces';
            break;
        }
    }
}

if (empty($svg_file_path) || !file_exists($svg_file_path)) {
    echo '<div class="notice notice-error"><p>' . esc_html__('فایل SVG نقشه یافت نشد.', 'iran-map') . '</p></div>';
    get_footer();
    return;
}

$svg_content = file_get_contents($svg_file_path);
$viewBox = '0 0 1000 920';
if (preg_match('/viewBox="([^"]+)"/', $svg_content, $m)) $viewBox = $m[1];
$initial_vb_parts = array_map('floatval', preg_split('/[\s,]+/', $viewBox));
$initial_vb = [
    'x' => $initial_vb_parts[0] ?? 0,
    'y' => $initial_vb_parts[1] ?? 0,
    'w' => $initial_vb_parts[2] ?? 1000,
    'h' => $initial_vb_parts[3] ?? 920,
];

$paths = [];
if (preg_match_all('/<path[^>]*id="([^"]+)"[^>]*data-slug="([^"]+)"[^>]*d="([^"]+)"[^>]*>/', $svg_content, $matches, PREG_SET_ORDER)) {
    foreach ($matches as $match) $paths[] = ['id' => $match[1], 'slug' => $match[2], 'd' => $match[3]];
} elseif (preg_match_all('/<path[^>]*id="([^"]+)"[^>]*d="([^"]+)"[^>]*>/', $svg_content, $matches2, PREG_SET_ORDER)) {
    foreach ($matches2 as $match) {
        $id = $match[1]; $slug = $id;
        if (strpos($id, 'province-') === 0) $slug = substr($id, 9);
        elseif (strpos($id, 'county-') === 0) { $parts = explode('-', $id); $slug = end($parts); }
        $paths[] = ['id' => $id, 'slug' => $slug, 'd' => $match[2]];
    }
} elseif (preg_match_all('/<path[^>]*d="([^"]+)"[^>]*>/', $svg_content, $matches3, PREG_SET_ORDER)) {
    $idx = 0;
    foreach ($matches3 as $match) { $paths[] = ['id' => 'path-' . $idx, 'slug' => 'region-' . $idx, 'd' => $match[1]]; $idx++; }
}

$region_by_slug = [];
foreach ($regions_data as $rd) {
    $slug = $rd['slug_en'] ?? '';
    if ($slug) $region_by_slug[$slug] = $rd;
    if (isset($rd['svg_id'])) $region_by_slug[$rd['svg_id']] = $rd;
}

$overall_min_x = null; $overall_min_y = null; $overall_max_x = null; $overall_max_y = null;
if ($map_type === 'provinces') {
    foreach ($regions_data as $rd) {
        if (($rd['type'] ?? '') !== 'province') continue;
        $bbox = $rd['bbox_lcc'] ?? null; if (!$bbox) continue;
        $min_x = $bbox['min_x'] ?? null; if ($min_x === null) continue;
        if ($overall_min_x === null || $min_x < $overall_min_x) $overall_min_x = $min_x;
        if ($overall_min_y === null || $bbox['min_y'] < $overall_min_y) $overall_min_y = $bbox['min_y'];
        if ($overall_max_x === null || $bbox['max_x'] > $overall_max_x) $overall_max_x = $bbox['max_x'];
        if ($overall_max_y === null || $bbox['max_y'] > $overall_max_y) $overall_max_y = $bbox['max_y'];
    }
} else {
    foreach ($regions_data as $rd) {
        if (($rd['type'] ?? '') !== 'county') continue;
        if (($rd['parent_slug'] ?? '') !== $test_province_slug) continue;
        $bbox = $rd['bbox_lcc'] ?? null; if (!$bbox) continue;
        $min_x = $bbox['min_x'] ?? null; if ($min_x === null) continue;
        if ($overall_min_x === null || $min_x < $overall_min_x) $overall_min_x = $min_x;
        if ($overall_min_y === null || $bbox['min_y'] < $overall_min_y) $overall_min_y = $bbox['min_y'];
        if ($overall_max_x === null || $bbox['max_x'] > $overall_max_x) $overall_max_x = $bbox['max_x'];
        if ($overall_max_y === null || $bbox['max_y'] > $overall_max_y) $overall_max_y = $bbox['max_y'];
    }
}
if ($overall_min_x === null) {
    $overall_min_x = $initial_vb['x']; $overall_min_y = $initial_vb['y'];
    $overall_max_x = $initial_vb['x'] + $initial_vb['w']; $overall_max_y = $initial_vb['y'] + $initial_vb['h'];
    $is_lcc_bounds = false;
} else {
    $is_lcc_bounds = true;
    $w = $overall_max_x - $overall_min_x; $h = $overall_max_y - $overall_min_y;
    $pad = max($w, $h) * 0.02;
    $overall_min_x -= $pad; $overall_min_y -= $pad; $overall_max_x += $pad; $overall_max_y += $pad;
}
function map_lcc_to_svg($lx, $ly, $ominx, $ominy, $omaxx, $omaxy, $sw, $sh) {
    $nx = ($lx - $ominx) / ($omaxx - $ominx);
    $ny = ($ly - $ominy) / ($omaxy - $ominy);
    return [$nx * $sw, (1 - $ny) * $sh];
}
$small_slugs = ['alborz','qom','tehran','qazvin','gilan','hamadan','golestan','kohgiluyeh-boyer-ahmad','chaharmahal-bakhtiari','ilam','zanjan','kurdistan','ardabil','markazi','lorestan','bushehr','semnan'];
?>

<div class="front-page-intro">
    <h1><?php esc_html_e('نقشه تعاملی ایران', 'iran-map'); ?></h1>
    <p><?php esc_html_e('جستجو، انتخاب استان/شهرستان، پنل اطلاعات، و مدیریت تاریخچه با hash /#/isfahan/kashan. کل flow با کیبورد کار می‌کند.', 'iran-map'); ?></p>
</div>

<div class="iran-map-layout" id="iran-map-layout">
    <div class="iran-map-main">
        <div class="iran-map-search-container" role="search">
            <label for="iran-map-search" class="screen-reader-text"><?php esc_html_e('جستجوی استان یا شهرستان', 'iran-map'); ?></label>
            <div class="iran-map-search-wrapper">
                <span class="iran-map-search-icon" aria-hidden="true">🔍</span>
                <input id="iran-map-search"
                       class="iran-map-search-input"
                       type="search"
                       role="combobox"
                       aria-autocomplete="list"
                       aria-expanded="false"
                       aria-controls="iran-map-search-list"
                       aria-label="<?php esc_attr_e('جستجوی استان یا شهرستان', 'iran-map'); ?>"
                       placeholder="<?php esc_attr_e('جستجوی استان یا شهرستان... (مثلاً کاشان یا تهران)', 'iran-map'); ?>"
                       autocomplete="off"
                       spellcheck="false" />
                <button id="iran-map-search-clear" class="iran-map-search-clear" type="button" aria-label="<?php esc_attr_e('پاک کردن جستجو', 'iran-map'); ?>" tabindex="-1">×</button>
            </div>
            <div id="iran-map-search-list" class="iran-map-search-list" role="listbox" aria-label="<?php esc_attr_e('نتایج جستجو', 'iran-map'); ?>"></div>
            <div id="iran-map-search-status" class="screen-reader-text" aria-live="polite" aria-atomic="true"></div>
        </div>

        <div id="iran-map-container" class="iran-map-container" data-map-type="<?php echo esc_attr($map_type); ?>" data-initial-viewbox="<?php echo esc_attr($viewBox); ?>" tabindex="0" aria-label="<?php esc_attr_e('نقشه تعاملی ایران', 'iran-map'); ?>">
            <div class="iran-map-controls" aria-label="<?php esc_attr_e('کنترل‌های نقشه', 'iran-map'); ?>">
                <button id="iran-map-zoom-in" type="button" aria-label="<?php esc_attr_e('بزرگنمایی', 'iran-map'); ?>">+</button>
                <button id="iran-map-zoom-out" type="button" aria-label="<?php esc_attr_e('کوچک‌نمایی', 'iran-map'); ?>">−</button>
                <button id="iran-map-reset" type="button" aria-label="<?php esc_attr_e('بازنشانی', 'iran-map'); ?>">⟲</button>
            </div>

            <div id="iran-map-loading" class="iran-map-loading" aria-hidden="true" role="status">
                <span class="iran-map-loading-spinner" aria-hidden="true"></span>
                <span><?php esc_html_e('در حال بارگذاری شهرستان‌ها...', 'iran-map'); ?></span>
            </div>

            <div id="iran-map-tooltip" class="iran-map-tooltip" role="tooltip" aria-hidden="true">
                <div class="iran-map-tooltip-photo"><span class="iran-map-tooltip-photo-placeholder" aria-hidden="true">🖼️</span></div>
                <div class="iran-map-tooltip-content">
                    <h3 class="iran-map-tooltip-title"></h3>
                    <div class="iran-map-tooltip-stats">
                        <div class="iran-map-tooltip-stat"><span class="label"><?php esc_html_e('مساحت', 'iran-map'); ?></span><span class="value" data-stat="area"></span></div>
                        <div class="iran-map-tooltip-stat"><span class="label"><?php esc_html_e('جمعیت', 'iran-map'); ?></span><span class="value" data-stat="population"></span></div>
                    </div>
                    <div class="iran-map-tooltip-capital" data-stat="capital"></div>
                </div>
            </div>

            <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="<?php echo esc_attr(intval($initial_vb['h'] * 1000 / $initial_vb['w'])); ?>" viewBox="<?php echo esc_attr($viewBox); ?>" role="img" aria-label="<?php esc_attr_e('نقشه ایران', 'iran-map'); ?>" shape-rendering="geometricPrecision">
                <defs>
                    <filter id="iran-map-shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#000" flood-opacity="0.2"/></filter>
                    <filter id="iran-map-shadow-strong" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000" flood-opacity="0.25"/></filter>
                </defs>
                <rect id="iran-map-bg" class="iran-map-bg" x="<?php echo esc_attr($initial_vb['x'] - $initial_vb['w']); ?>" y="<?php echo esc_attr($initial_vb['y'] - $initial_vb['h']); ?>" width="<?php echo esc_attr($initial_vb['w'] * 3); ?>" height="<?php echo esc_attr($initial_vb['h'] * 3); ?>" fill="transparent" pointer-events="all" />
                <g id="map-group">
                    <g id="provinces-group">
                    <?php foreach ($paths as $path_item):
                        $slug = $path_item['slug']; $svg_id = $path_item['id']; $d = $path_item['d'];
                        $rd = $region_by_slug[$slug] ?? $region_by_slug[$svg_id] ?? null;
                        if (!$rd && $map_type === 'counties') { foreach ($regions_data as $r) { if (($r['slug_en'] ?? '') === $slug && ($r['parent_slug'] ?? '') === $test_province_slug) { $rd = $r; break; } } }
                        $name_fa = $rd['name_fa'] ?? $slug;
                        $area = $rd['area_km2'] ?? ''; $pop = $rd['population'] ?? ''; $capital = $rd['capital'] ?? '';
                        $post_obj = $provinces_posts_map[$slug] ?? null;
                        if (!$post_obj && isset($rd['slug_en'])) $post_obj = $provinces_posts_map[$rd['slug_en']] ?? null;
                        $href = $post_obj ? get_permalink($post_obj) : ($map_type === 'provinces' ? home_url('/' . $slug . '/') : home_url('/' . ($rd['parent_slug'] ?? $test_province_slug) . '/' . $slug . '/'));
                        if (empty($href)) $href = home_url('/' . $slug . '/');
                        $cls = $map_type === 'provinces' ? 'province' : 'county';
                        ?>
                        <a href="<?php echo esc_url($href); ?>" class="iran-map-region-link" data-slug="<?php echo esc_attr($slug); ?>" aria-label="<?php echo esc_attr($name_fa); ?>">
                            <path id="<?php echo esc_attr($svg_id); ?>" data-slug="<?php echo esc_attr($slug); ?>" data-name-fa="<?php echo esc_attr($name_fa); ?>" data-area="<?php echo esc_attr($area); ?>" data-population="<?php echo esc_attr($pop); ?>" data-capital="<?php echo esc_attr($capital); ?>" class="<?php echo esc_attr($cls); ?>" d="<?php echo esc_attr($d); ?>" vector-effect="non-scaling-stroke" shape-rendering="geometricPrecision" />
                        </a>
                    <?php endforeach; ?>
                    </g>
                    <g id="counties-group" class="iran-map-counties-group" aria-hidden="true"></g>
                    <g id="ripple-group" class="iran-map-ripple-group" pointer-events="none"></g>

                    <?php if ($map_type === 'provinces'):
                        foreach ($paths as $pi):
                            $slug = $pi['slug']; if (!in_array($slug, $small_slugs)) continue;
                            $rd = $region_by_slug[$slug] ?? null; if (!$rd) continue;
                            $la = $rd['label_anchor_lcc'] ?? $rd['label_anchor'] ?? null; if (!$la) continue;
                            if ($is_lcc_bounds && isset($la['x'])) { list($sx,$sy) = map_lcc_to_svg($la['x'],$la['y'],$overall_min_x,$overall_min_y,$overall_max_x,$overall_max_y,$initial_vb['w'],$initial_vb['h']); $sx+=$initial_vb['x']; $sy+=$initial_vb['y']; } else continue;
                            $href = ($provinces_posts_map[$slug] ?? null) ? get_permalink($provinces_posts_map[$slug]) : home_url('/'.$slug.'/');
                            ?>
                            <a href="<?php echo esc_url($href); ?>" aria-label="<?php echo esc_attr($rd['name_fa'] ?? $slug); ?>"><circle class="iran-map-tap-zone" data-slug="<?php echo esc_attr($slug); ?>" cx="<?php echo esc_attr($sx); ?>" cy="<?php echo esc_attr($sy); ?>" r="20" /></a>
                        <?php endforeach; endif; ?>

                    <?php foreach ($paths as $pi):
                        $slug=$pi['slug']; $rd=$region_by_slug[$slug] ?? $region_by_slug[$pi['id']] ?? null;
                        if (!$rd && $map_type==='counties') { foreach ($regions_data as $r) { if (($r['slug_en']??'')===$slug && ($r['parent_slug']??'')===$test_province_slug) {$rd=$r; break;}}}
                        if (!$rd) continue; $name_fa=$rd['name_fa']??$slug; $la=$rd['label_anchor_lcc']??$rd['label_anchor']??null; if (!$la) continue;
                        if ($is_lcc_bounds && isset($la['x'])) { list($sx,$sy)=map_lcc_to_svg($la['x'],$la['y'],$overall_min_x,$overall_min_y,$overall_max_x,$overall_max_y,$initial_vb['w'],$initial_vb['h']); $sx+=$initial_vb['x']; $sy+=$initial_vb['y']; } else continue;
                        $area=$rd['area_km2']??0; $cls_label=$map_type==='provinces'?'iran-map-label iran-map-label--province':'iran-map-label iran-map-label--county';
                        ?>
                        <text class="<?php echo esc_attr($cls_label); ?>" x="<?php echo esc_attr($sx); ?>" y="<?php echo esc_attr($sy); ?>" data-slug="<?php echo esc_attr($slug); ?>" data-area="<?php echo esc_attr($area); ?>"><?php echo esc_html($name_fa); ?></text>
                    <?php endforeach; ?>

                    <?php if ($map_type==='provinces'):
                        $very_small=['alborz','tehran','qom']; $off=0;
                        foreach ($very_small as $vs):
                            if (!in_array($vs, array_column($paths,'slug'))) continue;
                            $rd=$region_by_slug[$vs]??null; if (!$rd) continue; $la=$rd['label_anchor_lcc']??null; if (!$la||!isset($la['x'])) continue;
                            list($sx,$sy)=map_lcc_to_svg($la['x'],$la['y'],$overall_min_x,$overall_min_y,$overall_max_x,$overall_max_y,$initial_vb['w'],$initial_vb['h']); $sx+=$initial_vb['x']; $sy+=$initial_vb['y'];
                            $cx=$sx+80+($off*10); $cy=$sy-30-($off*15);
                            ?>
                            <line class="iran-map-callout-line" x1="<?php echo esc_attr($sx); ?>" y1="<?php echo esc_attr($sy); ?>" x2="<?php echo esc_attr($cx); ?>" y2="<?php echo esc_attr($cy); ?>" />
                            <text class="iran-map-callout-label" x="<?php echo esc_attr($cx+4); ?>" y="<?php echo esc_attr($cy); ?>"><?php echo esc_html($rd['name_fa']??$vs); ?></text>
                            <?php $off++; endforeach; endif; ?>
                </g>
            </svg>
        </div>
    </div>

    <aside id="iran-map-panel" class="iran-map-panel" aria-hidden="true" role="complementary" aria-label="<?php esc_attr_e('اطلاعات منطقه', 'iran-map'); ?>">
        <div class="iran-map-panel-handle" id="iran-map-panel-handle" aria-hidden="true"><span></span></div>
        <button id="iran-map-panel-close" class="iran-map-panel-close" type="button" aria-label="<?php esc_attr_e('بستن پنل', 'iran-map'); ?>">×</button>
        <div class="iran-map-panel-content" id="iran-map-panel-content">
            <div class="iran-map-panel-photo">
                <span class="iran-map-panel-photo-placeholder" aria-hidden="true">🖼️</span>
                <img id="iran-map-panel-img" class="iran-map-panel-img" alt="" style="display:none;" />
            </div>
            <h2 id="iran-map-panel-title" class="iran-map-panel-title" tabindex="-1"></h2>
            <div id="iran-map-panel-summary" class="iran-map-panel-summary"></div>
            <div id="iran-map-panel-stats" class="iran-map-panel-stats"></div>
            <a id="iran-map-panel-link" class="iran-map-panel-link" href="#"><?php esc_html_e('مشاهده صفحه کامل', 'iran-map'); ?></a>
        </div>
    </aside>
</div>

<!-- SEO + no-JS fallback: real HTML list of all provinces and counties as <a> links, visible list view -->
<?php
$all_regions_for_seo = iran_map_get_all_regions_for_list();
$provinces_for_seo = [];
$counties_by_province = [];

if (!empty($all_regions_for_seo) && is_array($all_regions_for_seo) && isset($all_regions_for_seo[0]) && is_object($all_regions_for_seo[0])) {
    // WP_Post objects
    foreach ($all_regions_for_seo as $r) {
        if ($r->post_parent == 0) {
            $provinces_for_seo[] = $r;
        } else {
            $parent_id = $r->post_parent;
            if (!isset($counties_by_province[$parent_id])) $counties_by_province[$parent_id] = [];
            $counties_by_province[$parent_id][] = $r;
        }
    }
} else {
    // regions.json fallback
    foreach ($all_regions_for_seo as $rd) {
        if (($rd['type'] ?? '') === 'province') {
            $provinces_for_seo[] = $rd;
        } elseif (($rd['type'] ?? '') === 'county') {
            $parent = $rd['parent_slug'] ?? '';
            if (!isset($counties_by_province[$parent])) $counties_by_province[$parent] = [];
            $counties_by_province[$parent][] = $rd;
        }
    }
}
?>
<section class="iran-map-seo-list" aria-label="<?php esc_attr_e('فهرست همه استان‌ها و شهرستان‌ها', 'iran-map'); ?>">
    <h2><?php esc_html_e('فهرست همه استان‌ها و شهرستان‌ها (SEO + بدون جاوااسکریپت)', 'iran-map'); ?></h2>
    <p class="iran-map-seo-list-intro">
        <?php esc_html_e('این فهرست برای سئو و حالت بدون جاوااسکریپت است. با جاوااسکریپت غیرفعال، تمام صفحات از صفحه اصلی قابل دسترسی و خوانا هستند. هر لینک به صفحه واقعی استان/شهرستان می‌رود، و همچنین لینک به حالت نقشه با hash.', 'iran-map'); ?>
    </p>
    <div class="iran-map-seo-provinces">
        <?php foreach ($provinces_for_seo as $prov):
            $is_wp = is_object($prov);
            $prov_title = $is_wp ? $prov->post_title : ($prov['name_fa'] ?? $prov['slug_en']);
            $prov_slug = $is_wp ? $prov->post_name : ($prov['slug_en'] ?? '');
            $prov_url = $is_wp ? get_permalink($prov) : home_url('/' . $prov_slug . '/');
            $prov_map_url = home_url('/#/' . $prov_slug);
            $child_counties = $is_wp ? ($counties_by_province[$prov->ID] ?? []) : ($counties_by_province[$prov_slug] ?? []);
            ?>
            <div class="iran-map-seo-province">
                <h3 class="iran-map-seo-province-title">
                    <a href="<?php echo esc_url($prov_url); ?>"><?php echo esc_html($prov_title); ?></a>
                    <a href="<?php echo esc_url($prov_map_url); ?>" style="font-size:11px;color:#888;margin-inline-start:6px;" aria-label="<?php echo esc_attr(sprintf(__('نمایش %s روی نقشه', 'iran-map'), $prov_title)); ?>">🗺️</a>
                </h3>
                <?php if ($child_counties): ?>
                    <ul class="iran-map-seo-counties">
                        <?php
                        $count = 0;
                        foreach ($child_counties as $county):
                            if ($count >= 8) break;
                            $is_wp_c = is_object($county);
                            $county_title = $is_wp_c ? $county->post_title : ($county['name_fa'] ?? $county['slug_en']);
                            $county_slug = $is_wp_c ? $county->post_name : ($county['slug_en'] ?? '');
                            $county_url = $is_wp_c ? get_permalink($county) : home_url('/' . $prov_slug . '/' . $county_slug . '/');
                            $county_map_url = home_url('/#/' . $prov_slug . '/' . $county_slug);
                            $count++;
                            ?>
                            <li>
                                <a href="<?php echo esc_url($county_url); ?>"><?php echo esc_html($county_title); ?></a>
                                <a href="<?php echo esc_url($county_map_url); ?>" style="font-size:10px;color:#999;margin-inline-start:4px;">🗺️</a>
                            </li>
                        <?php endforeach; ?>
                        <?php if (count($child_counties) > 8): ?>
                            <li class="more"><a href="<?php echo esc_url($prov_url); ?>"><?php echo esc_html(sprintf(__('+%d شهرستان دیگر', 'iran-map'), count($child_counties) - 8)); ?></a></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<script id="iran-regions-data" type="application/json"><?php echo wp_json_encode($regions_data, JSON_UNESCAPED_UNICODE); ?></script>
<script id="iran-map-config" type="application/json"><?php echo wp_json_encode([
    'initialViewBox' => $viewBox,
    'mapType' => $map_type,
    'testProvince' => $test_province_slug,
    'countiesBaseUrl' => get_template_directory_uri() . '/assets/svg/counties/',
    'ajaxUrl' => admin_url('admin-ajax.php'),
], JSON_UNESCAPED_UNICODE); ?></script>

<div style="margin-block-start:1rem;font-size:0.875rem;color:#666;">
    <p><?php esc_html_e('گام ۶: قالب استان/شهرستان با hero AVIF/WebP srcset LCP not lazy placeholder, breadcrumb ایران > اصفهان > کاشان RTL, quick-facts, description, child-county grid, mini-map static SVG با لینک به hash map state, neighbors. صفحه اصلی فهرست HTML واقعی همه استان‌ها و شهرستان‌ها برای SEO و بدون JS. Page transitions با View Transitions API cross-document + fade fallback. JSON-LD Place + BreadcrumbList, title/description/canonical/OG, Rank Math/Yoast filter, region در sitemap.', 'iran-map'); ?></p>
</div>

<?php get_footer(); ?>
