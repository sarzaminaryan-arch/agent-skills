/**
 * Step 6: Page transitions with View Transitions API (cross-document), fade fallback
 * - If browser supports View Transitions API (cross-document via @view-transition navigation:auto), it will handle automatically
 * - Fallback: fade out on link click, fade in on load
 */
(function() {
    'use strict';

    // Check if View Transitions API is supported (cross-document)
    const supportsViewTransition = (() => {
        // Check for CSS @view-transition support or document.startViewTransition
        if ('startViewTransition' in document) return true;
        // Cross-document view transitions via meta tag is newer, but we assume if meta is present and browser is Chrome 126+
        // For fallback we still handle
        return CSS.supports('view-transition-name', 'root');
    })();

    if (supportsViewTransition) {
        // Let browser handle cross-document transitions via CSS @view-transition { navigation: auto; }
        // Optionally add view-transition-name to key elements
        document.documentElement.style.viewTransitionName = 'root';
        return;
    }

    // Fallback fade
    const FADE_DURATION = 200;

    function fadeOutAndNavigate(url) {
        document.body.classList.add('is-exiting');
        setTimeout(() => {
            window.location.href = url;
        }, FADE_DURATION);
    }

    document.addEventListener('DOMContentLoaded', () => {
        // Fade in on load
        document.body.style.opacity = '0';
        requestAnimationFrame(() => {
            document.body.style.transition = `opacity ${FADE_DURATION}ms ease-out`;
            document.body.style.opacity = '1';
        });

        // Intercept internal links for fade out
        document.querySelectorAll('a[href^="/"], a[href^="' + window.location.origin + '"]').forEach(link => {
            // Skip hash links, external, target blank, etc.
            const href = link.getAttribute('href');
            if (!href) return;
            if (href.startsWith('#')) return;
            if (link.target === '_blank') return;
            if (link.hasAttribute('download')) return;
            if (href.includes('#/')) return; // Map hash state, don't fade
            if (link.classList.contains('iran-map-region-link')) return; // Map links handled by map.js

            link.addEventListener('click', (e) => {
                // Only for same-origin navigations
                const url = new URL(link.href, window.location.origin);
                if (url.origin !== window.location.origin) return;
                // Allow modified clicks (ctrl, meta, etc.)
                if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
                e.preventDefault();
                fadeOutAndNavigate(url.href);
            });
        });
    });
})();
